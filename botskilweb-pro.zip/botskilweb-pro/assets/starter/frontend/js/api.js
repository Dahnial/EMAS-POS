// Semua komunikasi ke backend GAS. Token SELALU di body POST, tidak pernah di URL.
const Api = {
  sessionToken: null,

  async post(action, data) {
    try {
      const res = await fetch(CONFIG.GAS_URL, {
        method: 'POST',
        // WAJIB text/plain: menghindari CORS preflight yang tidak didukung GAS
        headers: { 'Content-Type': 'text/plain;charset=utf-8' },
        body: JSON.stringify({ action, data, sessionToken: this.sessionToken })
      });
      const hasil = await res.json();
      if (hasil.code === 'SESI_HABIS') Auth.keLogin('Sesi berakhir, silakan masuk lagi.');
      return hasil;
    } catch (err) {
      return { success: false, message: 'Tidak bisa terhubung ke server. Cek koneksi internet.' };
    }
  },

  async login(idToken) {
    try {
      const res = await fetch(CONFIG.GAS_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'text/plain;charset=utf-8' },
        body: JSON.stringify({ action: 'loginGoogle', idToken })
      });
      return await res.json();
    } catch (err) {
      return { success: false, message: 'Tidak bisa terhubung ke server.' };
    }
  }
};
