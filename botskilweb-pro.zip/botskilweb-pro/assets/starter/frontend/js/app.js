const UI = {
  esc(s) { // cegah XSS: SEMUA teks dari server harus lewat sini sebelum masuk innerHTML
    return String(s == null ? '' : s).replace(/[&<>"']/g, c =>
      ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  },
  toast(msg, jenis) {
    const el = document.getElementById('toast');
    el.textContent = msg; el.className = 'toast show ' + (jenis || '');
    setTimeout(() => el.classList.remove('show'), 3200);
  },
  setError(msg) { document.getElementById('loginError').textContent = msg || ''; }
};

const App = {
  data: [],

  tampil() {
    document.getElementById('viewLogin').hidden = true;
    document.getElementById('viewApp').hidden = false;
    document.getElementById('userInfo').textContent = Auth.user.nama + ' · ' + Auth.user.role;
    document.getElementById('formCard').hidden = !['admin', 'editor'].includes(Auth.user.role);
    App.muat();
  },

  async muat() {
    const r = await Api.post('getData');
    if (!r.success) return UI.toast(r.message, 'error');
    App.data = r.data; App.gambar();
  },

  gambar() {
    const tb = document.getElementById('tbody');
    if (!App.data.length) { tb.innerHTML = '<tr><td colspan="5" class="muted">Belum ada data.</td></tr>'; return; }
    const bisaHapus = Auth.user.role === 'admin';
    tb.innerHTML = App.data.map(d => `
      <tr><td>${UI.esc(d.judul)}</td><td>${UI.esc(d.catatan)}</td>
      <td>${UI.esc(d.dibuat_oleh)}</td><td>${UI.esc(d.dibuat)}</td>
      <td>${bisaHapus ? `<button class="btn btn-ghost" data-hapus="${UI.esc(d.id)}">Hapus</button>` : ''}</td></tr>`).join('');
  },

  async simpan(e) {
    e.preventDefault();
    const judul = document.getElementById('judul').value.trim();
    if (!judul) return UI.toast('Judul wajib diisi.', 'error');
    const catatan = document.getElementById('catatan').value;
    // Optimistic UI: tampil dulu, rapikan setelah server menjawab
    App.data.unshift({ id: 'tmp', judul, catatan, dibuat_oleh: Auth.user.email, dibuat: 'menyimpan…' });
    App.gambar(); e.target.reset();
    const r = await Api.post('saveData', { judul, catatan });
    UI.toast(r.message, r.success ? 'ok' : 'error');
    App.muat();
  },

  async hapus(id) {
    if (!confirm('Hapus data ini?')) return;
    const r = await Api.post('deleteData', { id });
    UI.toast(r.message, r.success ? 'ok' : 'error');
    App.muat();
  }
};

function setTema(t) { document.documentElement.dataset.theme = t; try { localStorage.setItem('tema', t); } catch (e) {} }

document.addEventListener('DOMContentLoaded', () => {
  let t = 'light';
  try { t = localStorage.getItem('tema') || (matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'); } catch (e) {}
  setTema(t);
  document.getElementById('themeBtn').onclick = () => setTema(document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark');
  document.getElementById('logoutBtn').onclick = () => Auth.keluar();
  document.getElementById('dataForm').addEventListener('submit', App.simpan);
  document.getElementById('tbody').addEventListener('click', e => {
    const id = e.target.dataset && e.target.dataset.hapus; if (id) App.hapus(id);
  });
  Auth.init();
});
