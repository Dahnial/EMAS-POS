// Login Google (Google Identity Services). Tidak ada password yang kita simpan.
const Auth = {
  user: null,

  init() {
    const siap = () => {
      if (!window.google || !google.accounts) return setTimeout(siap, 150);
      google.accounts.id.initialize({
        client_id: CONFIG.GOOGLE_CLIENT_ID,
        callback: (resp) => Auth.saatKredensial(resp)
      });
      google.accounts.id.renderButton(document.getElementById('googleBtn'),
        { theme: 'outline', size: 'large', text: 'signin_with', locale: 'id', width: 280 });
    };
    siap();
    // Pulihkan sesi bila tab belum ditutup
    const t = sessionStorage.getItem('sesi'), u = sessionStorage.getItem('user');
    if (t && u) { Api.sessionToken = t; Auth.user = JSON.parse(u); App.tampil(); }
  },

  async saatKredensial(resp) {
    UI.setError('');
    const hasil = await Api.login(resp.credential);
    if (!hasil.success) return UI.setError(hasil.message);
    Api.sessionToken = hasil.data.sessionToken;
    Auth.user = hasil.data.user;
    sessionStorage.setItem('sesi', Api.sessionToken);
    sessionStorage.setItem('user', JSON.stringify(Auth.user));
    App.tampil();
  },

  async keluar() {
    await Api.post('logout');
    if (window.google && google.accounts) google.accounts.id.disableAutoSelect();
    Auth.keLogin('');
  },

  keLogin(pesan) {
    sessionStorage.clear();
    Api.sessionToken = null; Auth.user = null;
    document.getElementById('viewApp').hidden = true;
    document.getElementById('viewLogin').hidden = false;
    UI.setError(pesan || '');
  }
};
