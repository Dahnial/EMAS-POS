// ISI DUA NILAI INI SEBELUM DEPLOY (keduanya aman dilihat publik).
const CONFIG = {
  GAS_URL: 'https://script.google.com/macros/s/ISI_ID_DEPLOYMENT/exec', // URL Web App berakhiran /exec
  GOOGLE_CLIENT_ID: 'ISI.apps.googleusercontent.com'                     // dari Google Cloud Console
};
