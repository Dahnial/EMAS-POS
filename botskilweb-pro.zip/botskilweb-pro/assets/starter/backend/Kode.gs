/**
 * ============================================================
 * botskilweb-pro — Backend Starter (Kode.gs)
 * GAS sebagai REST API (JSON) + Login Google + Hak Akses (role)
 * ------------------------------------------------------------
 * Cara pakai singkat:
 *  1. Ganti APP_NAME di bawah.
 *  2. Jalankan setupAppEnvironment() SEKALI (aman diulang, tidak menggandakan).
 *  3. Project Settings > Script Properties > tambah GOOGLE_CLIENT_ID
 *     (dari Google Cloud Console, lihat references/08-google-login.md).
 *  4. Deploy > New deployment > Web app > Execute as: Me, Who has access: Anyone.
 * ============================================================
 */

const APP_NAME = 'Nama Aplikasi';          // <- ganti
const SESSION_TTL_DETIK = 6 * 60 * 60;     // 6 jam (batas maksimum CacheService)
const CACHE_TTL_DATA = 300;                // 5 menit untuk data yang sering dibaca
const SHEET = { config: 'AppConfig', users: 'Users', data: 'Data' };
const HEADERS = {
  AppConfig: ['key', 'value', 'keterangan'],
  Users: ['email', 'nama', 'role', 'aktif', 'dibuat'],
  Data: ['id', 'dibuat', 'dibuat_oleh', 'judul', 'catatan']
};
// Siapa boleh melakukan apa. Tambah aksi baru di sini.
const IZIN = {
  getData:  ['admin', 'editor', 'viewer'],
  saveData: ['admin', 'editor'],
  deleteData: ['admin'],
  listUsers: ['admin']
};

// ───────────────────────── ENTRY POINTS ─────────────────────────

/** GET hanya untuk data PUBLIK (tanpa login). Jangan kirim token lewat URL. */
function doGet(e) {
  try {
    const action = (e && e.parameter && e.parameter.action) || 'ping';
    if (action === 'ping') return jsonOut({ success: true, message: APP_NAME + ' siap.' });
    if (action === 'publicInfo') return jsonOut({ success: true, data: { appName: APP_NAME } });
    return jsonOut({ success: false, message: 'Action GET tidak dikenal.' });
  } catch (err) {
    return jsonOut({ success: false, message: 'Terjadi kesalahan server.' });
  }
}

/** POST untuk semua yang butuh login. Body = JSON dikirim sebagai text/plain. */
function doPost(e) {
  try {
    const body = JSON.parse((e && e.postData && e.postData.contents) || '{}');
    const action = body.action;

    if (action === 'loginGoogle') return jsonOut(loginGoogle(body.idToken));

    // Semua aksi lain wajib sesi valid + izin role
    const sesi = cekSesi(body.sessionToken);
    if (!sesi) return jsonOut({ success: false, code: 'SESI_HABIS', message: 'Sesi berakhir, silakan login lagi.' });
    if (action === 'logout') return jsonOut(logout(body.sessionToken));
    if (!IZIN[action]) return jsonOut({ success: false, message: 'Action tidak dikenal.' });
    if (IZIN[action].indexOf(sesi.role) === -1) {
      return jsonOut({ success: false, code: 'DILARANG', message: 'Anda tidak punya izin untuk aksi ini.' });
    }

    let hasil;
    if (action === 'getData') hasil = getData();
    else if (action === 'saveData') hasil = saveData(body.data, sesi);
    else if (action === 'deleteData') hasil = deleteData(body.data && body.data.id);
    else if (action === 'listUsers') hasil = listUsers();
    return jsonOut(hasil);
  } catch (err) {
    Logger.log('doPost error: ' + err);
    return jsonOut({ success: false, message: 'Terjadi kesalahan server.' });
  }
}

function jsonOut(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}

// ───────────────────────── LOGIN GOOGLE ─────────────────────────

/**
 * Verifikasi ID token Google, cek email ada di sheet Users (daftar putih),
 * lalu terbitkan token sesi milik aplikasi (disimpan di CacheService).
 * CATATAN: endpoint tokeninfo cocok untuk aplikasi kecil-menengah. Untuk skala besar
 * pindah ke Level 5 (Next.js + library resmi Google) — lihat references/09-enterprise-upgrade.md.
 */
function loginGoogle(idToken) {
  if (!idToken || typeof idToken !== 'string') return { success: false, message: 'Token Google tidak ada.' };
  const clientId = prop_('GOOGLE_CLIENT_ID');
  if (!clientId) return { success: false, message: 'GOOGLE_CLIENT_ID belum diisi di Script Properties.' };

  const res = UrlFetchApp.fetch(
    'https://oauth2.googleapis.com/tokeninfo?id_token=' + encodeURIComponent(idToken),
    { muteHttpExceptions: true }
  );
  if (res.getResponseCode() !== 200) return { success: false, message: 'Token Google tidak valid.' };
  const c = JSON.parse(res.getContentText());

  const issOk = c.iss === 'accounts.google.com' || c.iss === 'https://accounts.google.com';
  const expOk = Number(c.exp) * 1000 > Date.now();
  const verified = c.email_verified === true || c.email_verified === 'true';
  if (c.aud !== clientId || !issOk || !expOk || !verified || !c.email) {
    return { success: false, message: 'Token Google ditolak.' };
  }

  const email = String(c.email).toLowerCase();
  const user = cariUser_(email);
  if (!user || !(user.aktif === true || String(user.aktif).toUpperCase() === 'TRUE')) {
    return { success: false, message: 'Email ' + email + ' belum terdaftar. Hubungi admin.' };
  }

  const token = Utilities.getUuid() + Utilities.getUuid().replace(/-/g, '');
  const sesi = { email: email, nama: user.nama || c.name || email, role: user.role, foto: c.picture || '' };
  CacheService.getScriptCache().put('sess_' + token, JSON.stringify(sesi), SESSION_TTL_DETIK);
  return { success: true, data: { sessionToken: token, user: sesi }, message: 'Login berhasil.' };
}

function cekSesi(token) {
  if (!token || typeof token !== 'string') return null;
  const raw = CacheService.getScriptCache().get('sess_' + token);
  return raw ? JSON.parse(raw) : null;
}

function logout(token) {
  CacheService.getScriptCache().remove('sess_' + token);
  return { success: true, message: 'Anda sudah keluar.' };
}

function cariUser_(email) {
  const baris = bacaSheet_(SHEET.users);
  for (let i = 0; i < baris.length; i++) {
    if (String(baris[i].email).toLowerCase() === email) return baris[i];
  }
  return null;
}

// ───────────────────────── DATA (cache + batch + lock) ─────────────────────────

function getData() {
  const cache = CacheService.getScriptCache();
  const hit = cache.get('data_all');
  if (hit) return { success: true, data: JSON.parse(hit) };
  const data = bacaSheet_(SHEET.data).map(function (r) { r.dibuat = tanggal_(r.dibuat); return r; });
  try { cache.put('data_all', JSON.stringify(data), CACHE_TTL_DATA); } catch (e) { /* data terlalu besar: abaikan */ }
  return { success: true, data: data };
}

function saveData(d, sesi) {
  d = d || {};
  const judul = String(d.judul || '').trim();
  if (!judul || judul.length > 200) return { success: false, message: 'Judul wajib diisi (maks. 200 karakter).' };
  const catatan = String(d.catatan || '').slice(0, 2000);

  const lock = LockService.getScriptLock();
  lock.waitLock(10000);
  try {
    const sh = sheet_(SHEET.data);
    const baris = [Utilities.getUuid(), new Date(), sesi.email, judul, catatan];
    sh.getRange(sh.getLastRow() + 1, 1, 1, baris.length).setValues([baris]);
    CacheService.getScriptCache().remove('data_all');
    return { success: true, data: { id: baris[0] }, message: 'Data berhasil disimpan.' };
  } finally {
    lock.releaseLock();
  }
}

function deleteData(id) {
  if (!id) return { success: false, message: 'ID wajib diisi.' };
  const lock = LockService.getScriptLock();
  lock.waitLock(10000);
  try {
    const sh = sheet_(SHEET.data);
    const nilai = sh.getDataRange().getValues();
    for (let i = nilai.length - 1; i >= 1; i--) {
      if (nilai[i][0] === id) {
        sh.deleteRow(i + 1);
        CacheService.getScriptCache().remove('data_all');
        return { success: true, message: 'Data dihapus.' };
      }
    }
    return { success: false, message: 'Data tidak ditemukan.' };
  } finally {
    lock.releaseLock();
  }
}

function listUsers() {
  return { success: true, data: bacaSheet_(SHEET.users).map(function (u) {
    return { email: u.email, nama: u.nama, role: u.role, aktif: u.aktif };
  }) };
}

// ───────────────────────── UTILITAS ─────────────────────────

function prop_(k) { return PropertiesService.getScriptProperties().getProperty(k); }

function sheet_(nama) {
  const ss = SpreadsheetApp.openById(prop_('SPREADSHEET_ID'));
  const sh = ss.getSheetByName(nama);
  if (!sh) throw new Error('Sheet ' + nama + ' tidak ada. Jalankan setupAppEnvironment().');
  return sh;
}

/** Baca seluruh sheet dalam SATU panggilan, kembalikan array objek. */
function bacaSheet_(nama) {
  const v = sheet_(nama).getDataRange().getValues();
  if (v.length < 2) return [];
  const h = v[0];
  return v.slice(1).map(function (row) {
    const o = {};
    h.forEach(function (k, i) { o[k] = row[i]; });
    return o;
  });
}

function tanggal_(v) {
  return v instanceof Date ? Utilities.formatDate(v, 'Asia/Jakarta', 'yyyy-MM-dd HH:mm') : v;
}

// ───────────────────────── SETUP OTOMATIS (aman diulang) ─────────────────────────

function setupAppEnvironment() {
  const props = PropertiesService.getScriptProperties();
  let ss;
  const id = props.getProperty('SPREADSHEET_ID');
  if (id) {
    ss = SpreadsheetApp.openById(id);               // sudah pernah setup: pakai yang lama
  } else {
    const folder = DriveApp.createFolder('📁 ' + APP_NAME);
    folder.createFolder('📂 Uploads');
    ss = SpreadsheetApp.create('🗃️ Database — ' + APP_NAME);
    DriveApp.getFileById(ss.getId()).moveTo(folder);
    props.setProperties({ SPREADSHEET_ID: ss.getId(), ROOT_FOLDER_ID: folder.getId() });
    Logger.log('📁 Folder: ' + folder.getUrl());
  }

  Object.keys(HEADERS).forEach(function (nama) {
    let sh = ss.getSheetByName(nama);
    if (!sh) {
      sh = ss.insertSheet(nama);
      sh.getRange(1, 1, 1, HEADERS[nama].length).setValues([HEADERS[nama]])
        .setFontWeight('bold').setBackground('#1E3A5F').setFontColor('#ffffff');
      sh.setFrozenRows(1);
    }
  });
  const bawaan = ss.getSheetByName('Sheet1');
  if (bawaan && ss.getSheets().length > 1) ss.deleteSheet(bawaan);

  // Admin pertama = pemilik script (hanya jika sheet Users masih kosong)
  const users = ss.getSheetByName(SHEET.users);
  if (users.getLastRow() < 2) {
    const email = Session.getEffectiveUser().getEmail();
    users.appendRow([email.toLowerCase(), 'Admin', 'admin', true, new Date()]);
    Logger.log('👤 Admin pertama: ' + email);
  }
  const data = ss.getSheetByName(SHEET.data);
  if (data.getLastRow() < 2) data.appendRow([Utilities.getUuid(), new Date(), 'sistem', 'Contoh data', 'Hapus baris ini kapan saja.']);

  const cfg = ss.getSheetByName(SHEET.config);
  if (cfg.getLastRow() < 2) {
    cfg.appendRow(['APP_NAME', APP_NAME, 'Nama aplikasi']);
    cfg.appendRow(['SPREADSHEET_ID', ss.getId(), 'ID spreadsheet ini']);
    cfg.appendRow(['DIBUAT', new Date().toISOString(), 'Tanggal setup']);
  }

  Logger.log('✅ Setup selesai. Spreadsheet: ' + ss.getUrl());
  Logger.log('➡️ Langkah berikut: isi Script Property GOOGLE_CLIENT_ID, lalu Deploy sebagai Web app.');
}
