# Level 3 — Panduan Deploy ke GitHub Pages (langkah demi langkah, lewat terminal)

> Dipakai oleh botskilweb-pro pada Level 3. Aturan "satu langkah kecil, tunggu bukti (screenshot)" di bawah
> berlaku PENUH. Tambahan dari botskilweb-pro: baca dulu bagian **Batasan Penggunaan Komersial** di
> `07-hosting-vercel-domain.md` sebelum menyarankan GitHub Pages untuk aplikasi bisnis.

# Panduan Deploy Frontend ke GitHub Pages

Gunakan skill ini untuk memandu pengguna yang **awam soal Git/GitHub** melewati seluruh proses instalasi frontend statis (HTML/CSS/JS, hasil build React/Vue, atau proyek seperti GAS-PRO-API) ke GitHub Pages. Anggap pengguna belum pernah membuka terminal untuk Git sebelumnya — jangan berasumsi mereka tahu istilah repository, branch, commit, atau push.

## Prinsip cara membantu

1. **Satu langkah kecil setiap saat, tunggu buktinya.** Jangan tumpahkan 10 perintah sekaligus dan berharap semua berhasil. Beri 1-3 perintah, jelaskan apa yang akan terjadi, lalu tunggu pengguna melapor (biasanya lewat screenshot terminal) sebelum lanjut ke langkah berikutnya. Pengguna awam sering terhenti di tempat yang tidak terduga (folder salah, lupa titik di akhir `git add .`, dll) — mengecek tiap langkah mencegah mereka nyasar jauh sebelum ketahuan.
2. **Baca screenshot terminal dengan teliti sebelum menjawab.** Pengguna akan sering menempel screenshot PowerShell/Terminal berisi histori perintah dan pesan error. Jangan minta mereka "jalankan lagi" tanpa membaca apa yang sudah terjadi — cari baris error/success terakhir, dan lanjutkan tepat dari situ. Kalau sudah berhasil (ada `[new branch]` atau `Writing objects: 100%`), katakan itu berhasil dan lanjut ke langkah berikutnya, jangan minta ulangi.
3. **Bedakan yang terlihat normal dari yang benar-benar error.** Dua kebingungan paling umum: (a) saat mengetik password/token di terminal, tidak ada karakter yang muncul sama sekali — ini normal, bukan bug; (b) GitHub sekarang menolak password akun biasa untuk `git push` dan mewajibkan Personal Access Token — pesan "Password authentication is not supported" bukan error fatal, itu sinyal untuk membuat token. Jelaskan ini SEBELUM pengguna mengalaminya kalau memungkinkan, supaya mereka tidak panik.
4. **Jelaskan istilah teknis sekali, singkat, saat pertama muncul** (repository, commit, push, branch) — lihat glosarium di bawah. Tidak perlu mengulang penjelasan tiap kali istilah itu dipakai lagi.
5. **Sesuaikan dengan proyek pengguna.** Kalau proyek punya file konfigurasi seperti `config.js` berisi URL backend (contoh: proyek GAS-PRO-API dengan `GAS_URL`), ingatkan untuk mengisinya SEBELUM push pertama, dan cek lagi kalau situs tampil kosong/error setelah deploy.
6. **SELALU lewat terminal, JANGAN pernah arahkan ke "Upload files" di web GitHub.** Upload via web GitHub ("Add file → Upload files") tidak menjaga struktur folder — semua file jadi rata di root. Ini menyebabkan CSS/JS 404 karena `index.html` merujuk ke `css/style.css` dan `js/app.js` yang tidak ada di folder tersebut. Selalu gunakan `git init` → `git add .` → `git push` dari terminal agar struktur folder (`css/`, `js/`, dll) otomatis ikut terjaga.
7. **Cek folder mana yang di-push SEBELUM `git init`, bukan sesudah.** Kesalahan paling mahal di panduan ini bukan salah ketik perintah, melainkan menjalankan `git init` satu level terlalu tinggi — sehingga yang terkirim adalah folder induk (berisi `backend/`, `frontend/`, panduan) alih-alih isi folder frontend. Hasilnya situs 404 padahal semua perintah git berhasil tanpa satu pun pesan error, jadi pengguna tidak punya petunjuk apa yang salah. Wajib verifikasi `dir`/`ls` menampilkan `index.html` di baris teratas SEBELUM `git init`. Lihat [Kontrak Struktur File](#kontrak-struktur-file-dengan-gas-pro-api).

## Kontrak Struktur File dengan gas-pro-api

Skill ini **wajib menginstruksikan** skill `gas-pro-api` (dan skill pembangkit kode apa pun yang hasilnya akan di-deploy ke GitHub Pages) untuk mematuhi kontrak di bawah. Kontrak ini bukan preferensi gaya — ia menutup satu-satunya kegagalan senyap dalam alur ini: **GitHub Pages hanya melihat `index.html` di root repository**, dan tidak ada perintah git yang akan memperingatkan kalau `index.html` terkubur satu level lebih dalam.

### Aturan 1 — Root ZIP = root repository

Folder hasil ekstraksi ZIP **adalah** folder yang di-`git init`. Tidak ada pembungkus `frontend/` di dalamnya, tidak ada folder induk yang harus dimasuki dulu.

```
✅ BENAR — isi ZIP                    ❌ SALAH — isi ZIP
nama-aplikasi/                        nama-aplikasi/
├── index.html         ← root         ├── backend/
├── README.md                         │   └── Kode.gs
├── PANDUAN-INSTALASI.md              ├── frontend/
├── css/                              │   ├── index.html   ← terkubur
│   └── style.css                     │   ├── css/
└── js/                               │   └── js/
    ├── config.js                     └── PANDUAN-INSTALASI.md
    ├── api.js
    ├── app.js
    └── ...
```

Struktur di kolom kanan **selalu** menghasilkan 404, karena pengguna secara naluriah menjalankan `git init` di folder teratas yang mereka lihat.

### Aturan 2 — Berkas backend TIDAK BOLEH masuk ZIP

`Kode.gs`, `appsscript.json`, dan berkas `.gs` lain **tidak pernah** dikemas bersama frontend. Dua alasannya:

- Berkas backend yang ikut terunggah menjadi sampah di repository publik, dan bagi pengguna awam menimbulkan keraguan apakah ada rahasia yang bocor.
- Kehadirannya di dalam ZIP mendorong pengguna membuat folder pembungkus, yang langsung melanggar Aturan 1.

### Aturan 3 — Cara penyampaian di chat/Cowork

| Jenis berkas | Cara diberikan | Alasan |
|---|---|---|
| `Kode.gs`, `appsscript.json`, `.gs` lain | **Berkas terpisah satu per satu** lewat `present_files` | Isinya disalin-tempel ke editor Apps Script. ZIP memaksa pengguna mengunduh, mengekstrak, lalu membuka dengan Notepad — tiga langkah untuk pekerjaan satu langkah |
| `index.html`, `css/`, `js/`, `README.md`, panduan | **Satu ZIP** | Perlu dipindahkan sebagai satu kesatuan dengan struktur folder utuh. Berkas terpisah memaksa pengguna membangun ulang folder `css/` dan `js/` secara manual, dan di situlah struktur biasanya rusak |
| Panduan instalasi | **`.md` atau `.pdf`, dan juga disajikan terpisah** di luar ZIP | Supaya bisa langsung dibaca sebagai pratinjau di dalam percakapan tanpa mengunduh apa pun. Panduan yang hanya ada di dalam ZIP tidak akan dibaca sebelum pengguna terlanjur salah langkah |

Panduan boleh berada di **dua tempat sekaligus**: satu salinan di dalam ZIP (agar tersimpan bersama proyek) dan satu berkas terpisah yang disajikan di chat (agar terbaca sekarang juga). Ini bukan duplikasi yang sia-sia — keduanya melayani momen yang berbeda.

### Aturan 4 — Panduan wajib menyebut jalur folder yang tepat

Saat menulis Tahap 5, sebutkan folder kerjanya secara eksplisit dan tegaskan bahwa itulah folder tempat `git init` dijalankan. Jangan menulis "masuk ke folder proyek Anda" tanpa menjelaskan folder yang mana, karena ada dua kandidat yang tampak masuk akal bagi pengguna.


## Alur lengkap (urutan yang harus diikuti)

### Tahap 1 — Cek & install Git
Tanyakan platform pengguna (Windows/Mac/Linux) kalau belum jelas dari konteks. Arahkan ke:
- **Windows:** `https://git-scm.com/download/win`, install dengan pengaturan default. Setelah install, buka **PowerShell** atau **Git Bash** dari Start Menu. Keduanya bisa dipakai — PowerShell lebih familiar untuk pengguna Windows, Git Bash punya perintah Linux.
- **Mac:** buka Terminal, ketik `git --version` — kalau belum ada, macOS akan menawarkan instalasi otomatis.
- **Linux:** `sudo apt install git` (Debian/Ubuntu) atau setara.

Verifikasi dengan:
```bash
git --version
```
Minta screenshot hasilnya sebelum lanjut.

### Tahap 2 — Buat akun GitHub (kalau belum ada)
Daftar di `https://github.com`. Username yang dipilih akan menjadi bagian URL situs mereka nanti (`username.github.io`), jadi ingatkan untuk memilih dengan sadar.

### Tahap 3 — Setup identitas Git (sekali saja, seumur hidup komputer itu)
Berikan dua perintah ini:
```bash
git config --global user.name "Nama Lengkap Anda"
git config --global user.email "email@sama-dengan-akun-github.com"
```
Jelaskan kalau ditanya: `user.name` BUKAN username GitHub dan BUKAN nama komputer — bebas apa saja, hanya label di histori commit. `user.email` sebaiknya sama dengan email akun GitHub supaya commit otomatis terhubung ke profil mereka, tapi ini tidak dipakai untuk login sehingga salah ketik pun tidak fatal.

Verifikasi:
```bash
git config --global user.name
git config --global user.email
```

### Tahap 4 — Buat repository baru di GitHub
Di github.com: tombol **+** → **New repository** → isi nama, pilih **Public** (wajib untuk Pages gratis), **JANGAN** centang README/.gitignore/license (supaya folder lokal bisa langsung push tanpa konflik). Biarkan halaman instruksi yang muncul tetap terbuka untuk disalin URL-nya nanti.

> **Kenapa Public?** GitHub Pages gratis hanya tersedia untuk repository publik. Ini aman — file frontend tidak memuat kredensial apa pun, hanya alamat API yang memang publik.

### Tahap 5 — Navigasi ke folder proyek & verifikasi struktur

Ini langkah yang **paling sering salah** bagi pemula. Pandu dengan sabar.

**Langkah 5a — Masuk ke folder proyek yang BENAR:**

Kalau proyek datang sebagai ZIP dari `gas-pro-api`, folder hasil ekstraksi itulah folder proyeknya — **jangan masuk lebih dalam, jangan naik satu level**. Sebutkan jalurnya secara eksplisit kepada pengguna, jangan hanya bilang "folder proyek Anda".

Kalau pengguna terlanjur punya folder induk berisi `backend/` dan `frontend/` (paket lama, atau mereka membuat pembungkus sendiri), folder kerjanya adalah **`frontend/`**, bukan induknya:

```
proyek-saya\            ← ❌ BUKAN di sini
├── backend\
├── frontend\          ← ✅ di sini
└── PANDUAN.md
```

```bash
cd "C:\path\ke\folder\proyek-anda"
```
Atau di Git Bash:
```bash
cd /c/Users/nama/Documents/folder-proyek
```

> 💡 Cara cepat di Windows: buka folder proyek di File Explorer, klik address bar, ketik `powershell` lalu Enter — PowerShell langsung terbuka di folder itu.

**Langkah 5b — Verifikasi isi folder:**

Di PowerShell:
```powershell
dir
```
Atau di Git Bash / Mac / Linux:
```bash
ls -la
```

Minta screenshot hasilnya. Yang harus dilihat:

1. **`index.html` harus ada di root** (bukan di dalam subfolder). Kalau yang muncul justru folder `frontend/` atau `backend/`, Anda berada satu level terlalu tinggi — `cd frontend` dulu, jangan lanjut. Ini gerbang paling penting di seluruh panduan: git akan menerima folder yang salah tanpa protes sedikit pun
2. **Struktur folder harus utuh** — file CSS dan JS harus **di dalam folder-nya**, bukan rata di root:
   ```
   ✅ BENAR:                    ❌ SALAH:
   index.html                   index.html
   css/                         style.css      ← harusnya di css/
     style.css                  config.js      ← harusnya di js/
   js/                          app.js         ← harusnya di js/
     config.js                  pages.js       ← harusnya di js/
     app.js
     pages.js
   ```
3. **Jangan ada file backend** (`.gs`) di folder frontend — file seperti `Kode.gs` dan `Modul.gs` hanya untuk Apps Script, bukan untuk GitHub Pages. Kalau ada, pindahkan ke folder lain atau hapus dari folder frontend sebelum push.

**Kalau struktur folder salah** (file rata di root tanpa folder `css/` dan `js/`): pandu pengguna membuat folder dan memindahkan file SEBELUM `git init`:

Di PowerShell:
```powershell
mkdir css
mkdir js
Move-Item style.css css\style.css
Move-Item config.js js\config.js
Move-Item app.js js\app.js
Move-Item pages.js js\pages.js
```

Di Git Bash / Mac / Linux:
```bash
mkdir -p css js
mv style.css css/
mv config.js app.js pages.js js/
```

Verifikasi lagi dengan `dir` atau `ls` setelah memindahkan.

**Langkah 5c — Cek file konfigurasi:**
Kalau proyek punya file config (`config.js`, `js/config.js`, atau sejenis) yang menyimpan URL API/backend:
- Pastikan sudah diisi URL yang benar — kalau belum, situs akan tampil error setelah online
- Contoh: proyek GAS-PRO-API punya `GAS_URL` di `js/config.js` yang harus diisi URL `/exec` dari Apps Script

### Tahap 6 — Inisialisasi Git & push pertama kali

Berikan perintah ini **satu per satu** (jangan sekaligus), minta screenshot setelah masing-masing:

**6a — Inisialisasi repositori Git lokal:**
```bash
git init
```
Hasil normal: `Initialized empty Git repository in ...`

**6b — Tambahkan semua file:**
```bash
git add .
```
> ⚠️ Ada **titik** di akhir perintah, artinya "tambahkan semua file di folder ini". Kalau lupa titiknya, tidak ada yang ditambahkan.

Hasil normal: tidak ada output (diam = berhasil).

**6c — Buat commit pertama:**
```bash
git commit -m "Upload pertama"
```
Hasil normal: muncul daftar file yang di-commit, seperti `create mode 100644 index.html`.

**6d — Ganti nama branch ke main:**
```bash
git branch -M main
```
Hasil normal: tidak ada output.

**6e — Sambungkan ke repo GitHub:**
```bash
git remote add origin https://github.com/USERNAME/NAMA-REPO.git
```
Ganti `USERNAME` dan `NAMA-REPO` dengan yang sebenarnya. Hasil normal: tidak ada output.

> Kalau muncul error `remote origin already exists`, artinya sudah pernah disambungkan. Lewati langkah ini, atau kalau URL-nya salah: `git remote set-url origin https://github.com/USERNAME/NAMA-REPO.git`

**6f — Push ke GitHub:**
```bash
git push -u origin main
```

Saat diminta:
- **Username:** ketik username GitHub
- **Password:** ketik/paste **Personal Access Token** (BUKAN password akun GitHub biasa)

> 💡 Saat mengetik/paste token, **layar terlihat kosong** — tidak ada karakter atau bintang muncul sama sekali. Ini **normal**, bukan tanda gagal. Di PowerShell: klik kanan untuk paste. Di Git Bash: Shift+Insert atau klik kanan → Paste. Lalu tekan Enter.

Tanda sukses: muncul baris `Writing objects: 100%...` dan `* [new branch] main -> main`.

Kalau muncul `Password authentication is not supported` → pandu Tahap 6g.

### Tahap 6g — Membuat Personal Access Token (kalau diperlukan)
1. Buka `https://github.com/settings/tokens` di browser
2. Klik **Generate new token** → pilih **Generate new token (classic)**
3. Isi:
   - **Note:** bebas, misal `git-push-token`
   - **Expiration:** `90 days` (atau `No expiration` kalau tidak mau repot perpanjang)
   - **Centang scope:** ✅ **repo** (ini wajib)
4. Klik **Generate token**
5. **Salin token** (`ghp_...`) — token ini **hanya tampil sekali**, simpan dulu di Notepad
6. Kembali ke terminal, jalankan `git push -u origin main` lagi
7. Paste token sebagai password

Kalau pengguna terus kesulitan dengan token/terminal, tawarkan alternatif **GitHub Desktop** (`https://desktop.github.com`) — login lewat browser, lalu **Add Local Repository** → pilih folder proyek → **Publish repository**. Ini jalur visual tanpa ketik token manual.

### Tahap 7 — Verifikasi repo di GitHub & aktifkan Pages

**7a — Cek struktur repo di GitHub:**
Buka `https://github.com/USERNAME/NAMA-REPO` di browser. Pastikan:
- Ada folder `css/` dan `js/` (bukan file CSS/JS rata di root)
- `index.html` ada di root
- Tidak ada file `.gs` (itu file backend, bukan frontend)

**Kalau file ternyata rata di root** (tidak ada folder `css/` dan `js/`), lihat **Prosedur Perbaikan** di bawah.

**7b — Aktifkan GitHub Pages:**
Di repo di github.com: **Settings** (tab paling kanan) → scroll ke **Pages** di sidebar kiri.

| Kolom | Nilai |
|---|---|
| Source | **Deploy from a branch** |
| Branch | **main** · **/ (root)** |
| Enforce HTTPS | ✅ **wajib dicentang** |

Klik **Save**. Tunggu 1-2 menit, refresh halaman. Akan muncul:
> "Your site is live at https://USERNAME.github.io/NAMA-REPO/"

> ⚠️ **Enforce HTTPS wajib** untuk proyek yang pakai mikrofon, kamera, atau geolokasi. Tanpa HTTPS, fitur-fitur ini diblokir browser.

**7c — Buka situs dan uji:**
Buka URL yang muncul. Kalau tampil benar, selamat! Kalau ada masalah, kirim screenshot — termasuk screenshot Console browser (F12 → tab Console) untuk melihat error.

### Tahap 8 — Cara update / redeploy
Setiap kali ada perubahan file, cukup 3 perintah dari folder proyek:
```bash
git add .
git commit -m "Deskripsi singkat perubahan"
git push
```
GitHub Pages otomatis rebuild dalam 1-2 menit. Kalau halaman masih tampil versi lama, itu cache browser — sarankan **Ctrl+Shift+R** (hard refresh) atau buka di jendela **Incognito/Private**.

---

## Prosedur Perbaikan: Salah Folder yang Di-push (404 File not found)

Gejalanya khas dan mudah dikenali:

- Situs menampilkan halaman **404 — File not found** dari GitHub Pages
- Semua perintah git berhasil, tidak ada satu pun pesan error
- Di halaman repository GitHub, yang terlihat di root adalah **folder** seperti `backend/` dan `frontend/`, bukan `index.html`

Penyebabnya: `git init` dijalankan di folder induk, bukan di folder frontend.

**Jangan** suruh pengguna menghapus repository dan mengulang dari nol. Cukup push ulang dari folder yang benar dan timpa isinya:

**Langkah 1 — Pindah ke folder frontend:**
```powershell
cd "C:\path\ke\proyek\frontend"
```

**Langkah 2 — Pastikan sudah di tempat yang benar:**
```powershell
dir
```
Wajib terlihat `index.html`, `css\`, dan `js\`. Kalau belum, jangan lanjut.

**Langkah 3 — Buat repositori git baru di folder ini:**
```powershell
git init
git add .
git commit -m "Fix: push dari folder frontend"
```

**Langkah 4 — Sambungkan dan timpa:**
```powershell
git branch -M main
git remote add origin https://github.com/USERNAME/NAMA-REPO.git
git push -u origin main --force
```

Jelaskan `--force` kepada pengguna sebelum mereka menjalankannya: perintah ini menimpa isi repository dengan versi lokal. Aman di sini karena isi lama memang struktur yang salah, tapi pengguna berhak tahu apa yang sedang mereka lakukan alih-alih menyalin perintah secara buta.

Tunggu 1-2 menit, buka situs, tekan **Ctrl+Shift+R**.

> Folder `.git` yang lama masih tertinggal di folder induk dan tidak mengganggu apa pun. Kalau pengguna ingin rapi, folder `.git` di induk boleh dihapus — tapi pastikan mereka menghapus yang di **induk**, bukan yang di `frontend/`.

---

## Prosedur Perbaikan: File Rata di Root (CSS/JS 404)

Ini masalah paling umum saat pengguna upload via web GitHub atau struktur folder tidak terjaga. Gejalanya:
- Halaman tampil tapi **tanpa styling** (teks polos, tidak ada warna/layout)
- Console browser (F12) menunjukkan **"Failed to load resource: 404"** untuk file `.css` dan `.js`
- Di repo GitHub, semua file ada di root **tanpa folder `css/` dan `js/`**

### Cara memperbaiki (via terminal):

**Langkah 1 — Clone repo:**
```bash
cd $HOME\Documents
git clone https://github.com/USERNAME/NAMA-REPO.git nama-repo-fix
cd nama-repo-fix
```
(Di Git Bash/Mac/Linux, ganti `$HOME\Documents` dengan `~/Documents`)

**Langkah 2 — Buat folder dan pindahkan file:**
```bash
mkdir css
mkdir js
git mv style.css css/style.css
git mv config.js js/config.js
git mv app.js js/app.js
git mv pages.js js/pages.js
```
> Sesuaikan nama file dengan yang ada di repo. `git mv` memindahkan file sekaligus mencatat perpindahannya di Git.

**Langkah 3 — Hapus file yang tidak seharusnya ada (opsional):**
Kalau ada file backend (`.gs`) yang tidak perlu di repo frontend:
```bash
git rm Kode.gs
git rm Modul.gs
```

**Langkah 4 — Commit dan push:**
```bash
git add .
git commit -m "Pindahkan file ke folder css/ dan js/"
git push
```

**Langkah 5 — Verifikasi:**
Tunggu 1-2 menit, buka situs GitHub Pages. Tekan **Ctrl+Shift+R** untuk hard refresh. Halaman seharusnya tampil lengkap dengan styling.

---

## Troubleshooting cepat (kenali dari pesan/screenshot)

| Yang terlihat | Penyebab | Solusi |
|---|---|---|
| `fatal: not a git repository` | Belum `git init`, atau folder salah | Cek `dir` / `ls` dulu, pastikan lihat file proyek, baru `git init` |
| `remote origin already exists` | `git remote add` sudah pernah jalan | Lewati, lanjut `git push`. Kalau URL salah: `git remote set-url origin <url>` |
| `Password authentication is not supported` | GitHub menolak password akun biasa | Buat Personal Access Token (Tahap 6g), gunakan sebagai password |
| `Invalid username or token` / `invalid credentials` | Token salah/kadaluarsa/belum dibuat | Buat token baru, pastikan tercentang scope **repo** |
| Tidak ada karakter muncul saat ketik password | Perilaku normal terminal | Tetap paste/ketik lalu Enter, layar memang tidak menampilkan apa pun |
| CSS/JS 404, halaman tanpa styling | File rata di root, folder `css/` `js/` tidak ada | Lihat **Prosedur Perbaikan** di atas |
| Halaman 404 di GitHub Pages | Branch/folder salah di Settings→Pages, atau `index.html` tidak di root | Cek Settings→Pages: branch main, folder root; pastikan `index.html` ada di root repo |
| 404, dan di repo GitHub terlihat folder `backend/` + `frontend/` di root | `git init` dijalankan di folder induk, bukan di `frontend/` | Lihat **Prosedur Perbaikan: Salah Folder yang Di-push** |
| 404, semua perintah git sukses tanpa error | Folder yang di-push salah — git tidak pernah memprotes hal ini | Buka repo di browser: kalau `index.html` tidak terlihat di root, folder-nya salah |
| Situs online tapi data/API tidak muncul | File config (URL backend) belum diisi/salah | Edit file config, isi URL benar, lalu `git add . && git commit -m "fix config" && git push` |
| Situs tampil versi lama setelah push | Cache browser | Ctrl+Shift+R atau buka Incognito |
| `error: src refspec main does not match any` | Belum ada commit | Jalankan `git add .` lalu `git commit -m "Upload pertama"` dulu |
| `Updates were rejected because the remote contains work` | Repo GitHub punya file (README dll) yang tidak ada di lokal | Jalankan `git pull --rebase origin main` lalu `git push` |
| `LF will be replaced by CRLF` (warning) | Perbedaan format baris Windows vs Linux | **Abaikan** — ini warning, bukan error. File tetap berfungsi normal |

## Glosarium (jelaskan sekali, saat relevan)

- **Repository (repo)** — folder proyek di GitHub, seperti Google Drive-nya programmer
- **Commit** — menyimpan perubahan dengan catatan singkat (seperti "Save" tapi tercatat riwayatnya, bisa dibatalkan)
- **Push** — mengirim commit dari komputer ke GitHub (seperti "Upload")
- **Clone** — mengunduh salinan repo dari GitHub ke komputer (seperti "Download")
- **Branch** — versi/cabang proyek (default yang dipakai: `main`)
- **Personal Access Token** — "password khusus" dari GitHub untuk operasi Git lewat terminal. GitHub tidak menerima password akun biasa untuk keamanan
- **Git Bash** — terminal khusus Git di Windows yang mendukung perintah Linux
- **PowerShell** — terminal bawaan Windows yang juga bisa menjalankan perintah Git

## Format output

Jawab dalam bahasa yang sama dengan pengguna (biasanya Bahasa Indonesia kasual-teknis). Jangan buat file PDF/markdown besar di awal kecuali diminta — pandu secara **percakapan langkah-demi-langkah**, karena pengguna perlu menjalankan tiap perintah dan melapor hasilnya sebelum lanjut.

Kalau pengguna secara eksplisit minta "panduan lengkap" atau "dokumen" untuk disimpan, baru buatkan file (Markdown atau PDF) yang merangkum seluruh tahap + troubleshooting + glosarium.

### Saat menyerahkan berkas hasil build

Patuhi [Kontrak Struktur File](#kontrak-struktur-file-dengan-gas-pro-api). Ringkasnya:

- Berkas backend (`.gs`, `appsscript.json`) → **disajikan satu per satu**, jangan di-ZIP
- Frontend (`index.html`, `css/`, `js/`, `README.md`) → **satu ZIP**, dengan `index.html` di root ZIP
- Panduan instalasi → **`.md` atau `.pdf`**, disajikan terpisah supaya bisa langsung dibaca di percakapan

Setelah menyerahkan ZIP, sebutkan secara eksplisit **folder mana yang nanti di-`git init`** — jangan biarkan pengguna menebak.

### Contoh format respons per langkah:
```
Bagus, Git sudah terpasang! ✓

Sekarang langkah berikutnya — setup identitas Git. Jalankan dua perintah ini:

[perintah]

[penjelasan singkat apa yang dilakukan perintah ini]

Kirim screenshot hasilnya ya!
```

Jangan campur lebih dari 3 perintah dalam satu respons. Tunggu konfirmasi sebelum lanjut.