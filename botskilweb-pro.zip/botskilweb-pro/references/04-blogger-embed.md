# Level 2b — Menampilkan GAS di Blogger (gabungan gas-to-blogger + opsi Blogger gas-pro-api)

Pilih berdasarkan jenis aplikasi:
| Jenis aplikasi | Cara |
|---|---|
| Monolit HtmlService (Level 2) | **Iframe** (Opsi A/B di bawah). Wajib `ALLOWALL` dan deployment akses "Siapa saja". |
| Frontend terpisah + GAS REST (Level 3) | **Page Blogger dengan override layar penuh** (Opsi C) — tanpa iframe. |

## Data yang dikumpulkan
URL `/exec` (bukan `/dev`) · target: (A) satu Page/Post [default, aman & bisa dibatalkan] atau (B) seluruh tema.
Ingatkan: akses deployment harus "Siapa saja", jika tidak iframe putih/diminta login.

## Opsi A — Page/Post (direkomendasikan)
Blogger → Laman/Pages → Laman baru → mode **Tampilan HTML** → tempel → Terbitkan.
```html
<div style="position:relative; width:100%; overflow:hidden; padding-top:150%;">
  <iframe src="URL_EXEC_ANDA" style="position:absolute; top:0; left:0; width:100%; height:100%; border:none;"
          loading="lazy" allow="camera; microphone; clipboard-write"></iframe>
</div>
```
`padding-top` mengatur tinggi (150% = tinggi). Atau iframe tinggi tetap `height:800px`. Layar penuh:
bungkus dengan `position:fixed; top:0; left:0; width:100%; height:100%; z-index:9999`.

## Opsi B — Ganti seluruh tema
Peringatkan: semua URL blog akan menampilkan app, navigasi/komentar bawaan hilang. **Cadangkan tema dulu**
(Tema → panah di samping Sesuaikan → Cadangkan/Pulihkan → Unduh). Edit HTML Blogger menolak HTML biasa; wajib XML
dengan namespace dan minimal satu `<b:section>` (kalau tidak: Error 400):
```xml
<?xml version="1.0" encoding="UTF-8" ?>
<html xmlns='http://www.w3.org/1999/xhtml' xmlns:b='http://www.google.com/2005/gml/b' xmlns:data='http://www.google.com/2005/gml/data' xmlns:expr='http://www.google.com/2005/gml/expr'>
<head><meta charset='UTF-8'/><meta content='width=device-width, initial-scale=1' name='viewport'/>
<title><data:blog.pageTitle/></title><b:skin><![CDATA[]]></b:skin></head>
<body style='margin:0; padding:0;'>
<b:section id='main' showaddelement='no'>
  <div style='position:fixed; top:0; left:0; width:100%; height:100%;'>
    <iframe src='URL_EXEC_ANDA' style='width:100%; height:100%; border:none;' loading='lazy' allow='camera; microphone; clipboard-write'></iframe>
  </div>
</b:section>
</body></html>
```

## Opsi C — Frontend native tanpa iframe (untuk Level 3, via Page)
Laman baru → HTML → tempel: `<style>` yang menyembunyikan header/nav/footer/sidebar/komentar tema + `#app` dengan
`position:fixed; inset:0; z-index:9999; overflow:auto`, lalu isi `index.html`, `<style>` CSS, dan `<script>` yang
berisi `CONFIG` + isi js (digabung inline). Selalu pilih Page (bukan edit tema) — aman dan mudah dibatalkan.
Catatan: tombol Google Sign-In butuh domain blog (mis. `https://namablog.blogspot.com`) didaftarkan sebagai
*Authorized JavaScript origin* (lihat `08-google-login.md`).

## Domain sendiri
Blogger gratis + pemetaan domain gratis (beli domain di registrar, atur DNS di Setelan → Penerbitan);
subdomain `blogspot.com` gratis. WordPress.com butuh paket berbayar untuk domain sendiri.

## Masalah umum
Iframe putih → akses deployment bukan "Siapa saja" atau kode memakai API yang rusak di iframe ·
Error 400 "no section" → `<b:section>` hilang · konten terpotong → ubah `padding-top`/tinggi ·
URL berubah saat klik menu → ada `?page=`/`window.location` (lihat aturan iframe di `03-gas-monolith.md`).
