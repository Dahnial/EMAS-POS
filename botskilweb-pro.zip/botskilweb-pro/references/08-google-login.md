# Level 4/5 — Login dengan Google (Gmail) + hak akses per peran

Prinsip: **tidak ada password yang kita simpan**. Google membuktikan identitas; aplikasi memutuskan *siapa boleh masuk*
(daftar putih email di sheet `Users`) dan *boleh melakukan apa* (peran: admin / editor / viewer).

## Alur
```
Browser: tombol "Masuk dengan Google" (Google Identity Services) → Google mengembalikan ID token (JWT)
→ POST {action:'loginGoogle', idToken} ke GAS
→ GAS memeriksa token (aud = Client ID kita, iss Google, belum kedaluwarsa, email_verified)
→ cek email ada di sheet Users & aktif → terbitkan sessionToken acak (CacheService, 6 jam)
→ semua aksi berikutnya: POST {action, sessionToken, data} → GAS cek sesi + izin peran (tabel IZIN)
```
Implementasi lengkap dan teruji: `assets/starter/` (`Kode.gs`: `loginGoogle`, `cekSesi`, `IZIN`; frontend: `js/auth.js`).

## Langkah di Google Cloud Console (pandu satu per satu, minta screenshot)
1. console.cloud.google.com → buat **Project** baru.
2. **Google Auth Platform / OAuth consent screen**: tipe *External*; isi nama aplikasi, email dukungan, logo (opsional),
   domain resmi, tautan **Kebijakan Privasi** (buat halaman sederhana — wajib bila dipublikasikan). Scope cukup
   dasar (`openid`, `email`, `profile`).
3. Status *Testing*: hanya "Test users" yang bisa login — tambahkan email Anda. Untuk umum, ubah ke *In production*
   (scope dasar umumnya tidak butuh peninjauan Google; ikuti petunjuk di konsol).
4. **Credentials → Create credentials → OAuth client ID → Web application**.
   **Authorized JavaScript origins** (tanpa garis miring akhir, tanpa path):
   `https://USERNAME.github.io`, `https://nama-proyek.vercel.app`, `https://domain-anda.com`,
   untuk uji lokal `http://localhost` dan `http://localhost:5500` (sesuai port). Redirect URI **tidak diperlukan**
   untuk tombol Google Identity Services.
5. Salin **Client ID** (`xxxx.apps.googleusercontent.com`; boleh publik) ke:
   - `js/config.js` → `GOOGLE_CLIENT_ID`
   - GAS → Project Settings → **Script Properties** → `GOOGLE_CLIENT_ID`
6. Perubahan origin bisa butuh beberapa menit–jam untuk berlaku.

## Mengelola pengguna
Sheet `Users`: `email | nama | role | aktif | dibuat`. Admin pertama dibuat otomatis (pemilik script) oleh
`setupAppEnvironment()`. Menambah orang = tambah baris (atau bangun halaman admin "Kelola Pengguna" memakai pola CRUD).
Email tak terdaftar ditolak dengan pesan ramah ("Hubungi admin"). Jangan buka pendaftaran otomatis tanpa persetujuan admin.

## Keamanan — jujur tentang batas
- Starter memakai endpoint `tokeninfo` Google dengan pemeriksaan klaim lengkap. Dokumentasi Google menyebut endpoint ini
  **untuk pengembangan/debug**; untuk produksi berskala, verifikasi tanda tangan JWT dengan pustaka resmi
  (`google-auth-library`) di server Node/Next.js → itu salah satu alasan **Level 5** (`09`). Karena `tokeninfo`
  hanya dipanggil saat login (bukan tiap aksi), pemakaian kecil–menengah aman.
- Sesi disimpan di `CacheService`; bisa hilang bila cache dibersihkan → pengguna cukup login ulang.
- Token sesi disimpan di `sessionStorage` (hilang saat tab ditutup). Semua teks dari server di-*escape* agar XSS tidak
  mencuri token. Jangan pernah menaruh token di URL.
- Batasi pemilik Spreadsheet/Drive (jangan bagikan publik). Catat aksi penting di sheet `Log`
  (siapa, kapan, apa) untuk audit — pola `saveData` bisa ditiru.
- GAS "Anyone" berarti siapa saja bisa memanggil URL; **semua data sensitif harus lewat POST + sesi + izin**.
- Hindari menyimpan data sensitif (NIK, kartu, kata sandi) di Sheets tanpa kebutuhan jelas.

## Masalah umum login
| Gejala | Penyebab / solusi |
|---|---|
| "The given origin is not allowed for the given client ID" / origin_mismatch | Origin situs belum didaftarkan persis (https, tanpa `/` akhir, tanpa path); tunggu propagasi |
| Tombol Google tidak muncul | `GOOGLE_CLIENT_ID` salah/kosong di `config.js`; skrip GSI diblokir (adblock); jendela privat memblokir cookie pihak ketiga |
| "Token Google ditolak" | Client ID di Script Properties ≠ di `config.js`; jam perangkat salah; token kedaluwarsa |
| "Email ... belum terdaftar" | Tambahkan ke sheet `Users` (huruf kecil, `aktif` = TRUE) |
| "Access blocked: app has not completed verification" / hanya test user | Status consent screen masih *Testing* → tambahkan test user atau publish |
| Selalu "Sesi berakhir" | Cache GAS dibersihkan atau lewat 6 jam; login ulang |
| "Anda tidak punya izin" | Peran tidak ada di tabel `IZIN` untuk aksi itu |
