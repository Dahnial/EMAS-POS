# Backend Patterns — Kode.gs

Comprehensive patterns for the server-side Google Apps Script file. Every function that can fail
is wrapped in try-catch and returns a standardized response object.

---

## File Header & Helpers

```javascript
/**
 * ============================================================
 * [NAMA APLIKASI] — Backend (Kode.gs)
 * Deskripsi: [Deskripsi singkat]
 * Versi: 1.0
 * ============================================================
 */

// ── Konstanta Global ──
const APP_NAME = 'NamaAplikasi';
const FOLDER_NAME = 'Folder_NamaAplikasi';
const SS_NAME = 'DB_NamaAplikasi';

// ── Helper: Include HTML Partial ──
function include(filename) {
  return HtmlService.createHtmlOutputFromFile(filename).getContent();
}

// ── Helper: Response Builder ──
function createResponse(success, data, message) {
  return { success: success, data: data, message: message };
}

// ── Helper: Generate UUID ──
function generateUUID() {
  return Utilities.getUuid();
}
```

---

## doGet — Single Entry Point

```javascript
function doGet(e) {
  const html = HtmlService.createTemplateFromFile('Index')
    .evaluate()
    .setTitle(APP_NAME)
    .addMetaTag('viewport', 'width=device-width, initial-scale=1')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
  return html;
}
```

The `setXFrameOptionsMode(ALLOWALL)` is important if the app will be embedded in an iframe
(e.g., inside Blogger or another site). Always include it.

---

## Auto-Setup: setupAppEnvironment()

This function is run once manually by the admin. It creates all infrastructure and is idempotent
(safe to re-run — it checks for existing resources before creating).

### Pattern

```javascript
function setupAppEnvironment() {
  try {
    // 1. Buat atau temukan Folder Utama di Drive
    const folders = DriveApp.getFoldersByName(FOLDER_NAME);
    const mainFolder = folders.hasNext()
      ? folders.next()
      : DriveApp.createFolder(FOLDER_NAME);
    Logger.log('📁 Folder: ' + mainFolder.getUrl());

    // 2. Buat sub-folder untuk lampiran (jika ada fitur upload)
    let uploadFolder;
    const subFolders = mainFolder.getFoldersByName('Lampiran');
    if (subFolders.hasNext()) {
      uploadFolder = subFolders.next();
    } else {
      uploadFolder = mainFolder.createFolder('Lampiran');
    }

    // 3. Buat atau temukan Spreadsheet
    let ss;
    const files = mainFolder.getFilesByName(SS_NAME);
    if (files.hasNext()) {
      ss = SpreadsheetApp.open(files.next());
    } else {
      ss = SpreadsheetApp.create(SS_NAME);
      DriveApp.getFileById(ss.getId()).moveTo(mainFolder);
    }
    Logger.log('📊 Spreadsheet: ' + ss.getUrl());

    // 4. Buat sheet-sheet yang dibutuhkan dengan header + data dummy
    createSheetIfNotExists(ss, 'DataUtama', 
      ['ID', 'Nama', 'Kategori', 'Tanggal', 'Status'],
      [generateUUID(), 'Contoh Data', 'Umum', new Date().toLocaleDateString('id-ID'), 'Aktif']
    );

    createSheetIfNotExists(ss, 'MasterKategori',
      ['ID', 'NamaKategori', 'Deskripsi'],
      [generateUUID(), 'Umum', 'Kategori default']
    );

    createSheetIfNotExists(ss, 'AppConfig',
      ['Key', 'Value'],
      ['appName', APP_NAME],
      ['folderId', mainFolder.getId()],
      ['uploadFolderId', uploadFolder.getId()],
      ['spreadsheetId', ss.getId()],
      ['logoUrl', ''],
      ['adminEmail', Session.getActiveUser().getEmail()]
    );

    // Hapus Sheet1 default jika masih ada
    const defaultSheet = ss.getSheetByName('Sheet1');
    if (defaultSheet && ss.getSheets().length > 1) {
      ss.deleteSheet(defaultSheet);
    }

    Logger.log('✅ Setup selesai!');
    Logger.log('📁 Folder ID: ' + mainFolder.getId());
    Logger.log('📊 Spreadsheet ID: ' + ss.getId());

    return createResponse(true, {
      folderId: mainFolder.getId(),
      spreadsheetId: ss.getId()
    }, 'Setup berhasil!');

  } catch (error) {
    Logger.log('❌ Error setup: ' + error.message);
    return createResponse(false, null, error.message);
  }
}

/**
 * Buat sheet jika belum ada, lengkap dengan header dan data dummy.
 * Menerima header sebagai array, lalu baris data sebagai arguments selanjutnya.
 */
function createSheetIfNotExists(ss, sheetName, headers, ...dataRows) {
  let sheet = ss.getSheetByName(sheetName);
  if (!sheet) {
    sheet = ss.insertSheet(sheetName);
    sheet.appendRow(headers);
    dataRows.forEach(row => sheet.appendRow(row));
    // Format header
    sheet.getRange(1, 1, 1, headers.length)
      .setFontWeight('bold')
      .setBackground('#4285f4')
      .setFontColor('#ffffff');
    // Auto-resize columns
    headers.forEach((_, i) => sheet.autoResizeColumn(i + 1));
  }
  return sheet;
}
```

### Key points about setupAppEnvironment
- Always idempotent — check before creating.
- AppConfig sheet stores all configuration as key-value pairs.
- Log every important URL/ID so the admin can verify in Execution Log.
- Create at least one dummy row per data sheet so the app isn't empty on first load.

---

## Reading the Spreadsheet ID

After setup, backend functions need to find the spreadsheet. Two reliable patterns:

**Pattern A: Script Properties** (fastest, set once during setup)
```javascript
function getSpreadsheet() {
  const ssId = PropertiesService.getScriptProperties().getProperty('spreadsheetId');
  return SpreadsheetApp.openById(ssId);
}
```

**Pattern B: Drive folder search** (self-healing, no manual config)
```javascript
function getSpreadsheet() {
  const folders = DriveApp.getFoldersByName(FOLDER_NAME);
  if (!folders.hasNext()) throw new Error('Folder aplikasi belum dibuat. Jalankan setupAppEnvironment().');
  const files = folders.next().getFilesByName(SS_NAME);
  if (!files.hasNext()) throw new Error('Spreadsheet belum dibuat. Jalankan setupAppEnvironment().');
  return SpreadsheetApp.open(files.next());
}
```

Choose Pattern A if the app serves many users concurrently (fewer API calls). Use Pattern B for
simpler apps where self-healing is preferred.

---

## CRUD Operations — Batch Pattern

The core principle: read the entire sheet once, process in memory, write back in bulk.

### Read All

```javascript
function getAllData(sheetName) {
  try {
    const ss = getSpreadsheet();
    const sheet = ss.getSheetByName(sheetName);
    if (!sheet) return createResponse(false, null, `Sheet "${sheetName}" tidak ditemukan.`);

    const data = sheet.getDataRange().getValues();
    if (data.length <= 1) return createResponse(true, [], 'Belum ada data.');

    const headers = data[0];
    const records = data.slice(1).map(row => {
      const obj = {};
      headers.forEach((h, i) => obj[h] = row[i]);
      return obj;
    });

    return createResponse(true, records, 'OK');
  } catch (error) {
    return createResponse(false, null, error.message);
  }
}
```

### Create

```javascript
function addRecord(sheetName, recordObj) {
  try {
    const ss = getSpreadsheet();
    const sheet = ss.getSheetByName(sheetName);
    const headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0];

    recordObj.ID = generateUUID();
    const newRow = headers.map(h => recordObj[h] || '');
    sheet.appendRow(newRow);

    return createResponse(true, recordObj, 'Data berhasil ditambahkan.');
  } catch (error) {
    return createResponse(false, null, error.message);
  }
}
```

### Update

```javascript
function updateRecord(sheetName, recordObj) {
  try {
    const ss = getSpreadsheet();
    const sheet = ss.getSheetByName(sheetName);
    const data = sheet.getDataRange().getValues();
    const headers = data[0];
    const idCol = headers.indexOf('ID');

    const rowIndex = data.findIndex((row, i) => i > 0 && row[idCol] === recordObj.ID);
    if (rowIndex === -1) return createResponse(false, null, 'Data tidak ditemukan.');

    const updatedRow = headers.map(h => recordObj[h] !== undefined ? recordObj[h] : data[rowIndex][headers.indexOf(h)]);
    sheet.getRange(rowIndex + 1, 1, 1, headers.length).setValues([updatedRow]);

    return createResponse(true, recordObj, 'Data berhasil diperbarui.');
  } catch (error) {
    return createResponse(false, null, error.message);
  }
}
```

### Delete

```javascript
function deleteRecord(sheetName, id) {
  try {
    const ss = getSpreadsheet();
    const sheet = ss.getSheetByName(sheetName);
    const data = sheet.getDataRange().getValues();
    const idCol = data[0].indexOf('ID');

    const rowIndex = data.findIndex((row, i) => i > 0 && row[idCol] === id);
    if (rowIndex === -1) return createResponse(false, null, 'Data tidak ditemukan.');

    sheet.deleteRow(rowIndex + 1);
    return createResponse(true, null, 'Data berhasil dihapus.');
  } catch (error) {
    return createResponse(false, null, error.message);
  }
}
```

---

## AppConfig Management

```javascript
function getConfig(key) {
  try {
    const ss = getSpreadsheet();
    const sheet = ss.getSheetByName('AppConfig');
    const data = sheet.getDataRange().getValues();
    const row = data.find(r => r[0] === key);
    return row ? row[1] : null;
  } catch (error) {
    return null;
  }
}

function setConfig(key, value) {
  try {
    const ss = getSpreadsheet();
    const sheet = ss.getSheetByName('AppConfig');
    const data = sheet.getDataRange().getValues();
    const rowIndex = data.findIndex(r => r[0] === key);

    if (rowIndex >= 0) {
      sheet.getRange(rowIndex + 1, 2).setValue(value);
    } else {
      sheet.appendRow([key, value]);
    }
    return createResponse(true, null, 'Konfigurasi disimpan.');
  } catch (error) {
    return createResponse(false, null, error.message);
  }
}

function getAllConfig() {
  try {
    const ss = getSpreadsheet();
    const sheet = ss.getSheetByName('AppConfig');
    const data = sheet.getDataRange().getValues();
    const config = {};
    data.slice(1).forEach(row => config[row[0]] = row[1]);
    return createResponse(true, config, 'OK');
  } catch (error) {
    return createResponse(false, null, error.message);
  }
}
```

---

## File Upload to Drive

```javascript
function uploadFileToDrive(fileData, fileName, mimeType) {
  try {
    const uploadFolderId = getConfig('uploadFolderId');
    if (!uploadFolderId) throw new Error('Folder upload belum dikonfigurasi.');

    const folder = DriveApp.getFolderById(uploadFolderId);
    const decoded = Utilities.base64Decode(fileData);
    const blob = Utilities.newBlob(decoded, mimeType, fileName);
    const file = folder.createFile(blob);

    return createResponse(true, {
      fileId: file.getId(),
      fileUrl: file.getUrl(),
      fileName: file.getName()
    }, 'File berhasil diupload.');
  } catch (error) {
    return createResponse(false, null, error.message);
  }
}
```

---

## Dashboard Data Aggregation

Aggregate data server-side, not client-side, to keep the frontend fast. Return pre-computed
summaries.

```javascript
function getDashboardData() {
  try {
    const ss = getSpreadsheet();
    const sheet = ss.getSheetByName('DataUtama');
    const data = sheet.getDataRange().getValues();
    const headers = data[0];
    const records = data.slice(1);

    // Hitung summary cards
    const totalRecords = records.length;
    const statusCol = headers.indexOf('Status');
    const statusCounts = {};
    records.forEach(row => {
      const status = row[statusCol] || 'Tidak Diketahui';
      statusCounts[status] = (statusCounts[status] || 0) + 1;
    });

    // Data untuk chart (contoh: per kategori)
    const catCol = headers.indexOf('Kategori');
    const categoryCounts = {};
    records.forEach(row => {
      const cat = row[catCol] || 'Lainnya';
      categoryCounts[cat] = (categoryCounts[cat] || 0) + 1;
    });

    // AI-style insight (teks analisis otomatis)
    const topCategory = Object.entries(categoryCounts)
      .sort((a, b) => b[1] - a[1])[0];
    const insights = [];
    if (topCategory) {
      const pct = ((topCategory[1] / totalRecords) * 100).toFixed(1);
      insights.push(`Kategori "${topCategory[0]}" mendominasi dengan ${pct}% dari total data.`);
    }
    insights.push(`Total data tercatat: ${totalRecords} entri.`);

    return createResponse(true, {
      totalRecords,
      statusCounts,
      categoryCounts,
      insights
    }, 'OK');
  } catch (error) {
    return createResponse(false, null, error.message);
  }
}
```

---

## Concurrency Safety

For apps with multiple simultaneous users writing data:

```javascript
function safeAddRecord(sheetName, recordObj) {
  const lock = LockService.getScriptLock();
  try {
    lock.waitLock(10000); // tunggu max 10 detik
    const result = addRecord(sheetName, recordObj);
    return result;
  } catch (error) {
    return createResponse(false, null, 'Sistem sedang sibuk, coba lagi: ' + error.message);
  } finally {
    lock.releaseLock();
  }
}
```

Use `LockService` for Create, Update, and Delete operations when the app has concurrent users.
Read operations don't need locks.

---

## Summary of Backend Architecture Rules

1. Every function returns `{ success: boolean, data: any, message: string }`.
2. Every function is wrapped in try-catch.
3. Never call Sheets API inside a loop — read once, process in memory, write once.
4. UUID for record identity, not row numbers (rows shift on delete).
5. `setupAppEnvironment()` is idempotent and logs all created resource URLs.
6. AppConfig sheet holds all runtime configuration.
7. Comments in Bahasa Indonesia.
