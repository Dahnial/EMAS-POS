# Level 2 — Aplikasi GAS "Monolit" (HtmlService SPA) — gabungan gas-webapp + gas-instant-ux + gas-spa-iframe

Level pertama yang langsung jadi: satu URL `/exec` berisi frontend + backend. Cocok untuk belajar, alat internal,
dan prototipe. Detail kode ada di `03a-backend-patterns.md` (Kode.gs) dan `03b-frontend-patterns.md`
(Index/Stylesheet/JavaScript). **Baca keduanya sebelum menulis kode**, lalu terapkan aturan keputusan di bawah
yang MENGGANTIKAN bagian yang bertentangan di file tersebut.

## Arsitektur: 4 file
`Kode.gs` (backend) · `Index.html` (cangkang) · `Stylesheet.html` (CSS + tema terang/gelap) · `JavaScript.html` (SPA).
`doGet()` dipanggil sekali dan mengembalikan `Index.html` dengan `include('Stylesheet')` dan `include('JavaScript')`.

## Aturan keputusan (hasil penyatuan skill — ikuti ini bila ada konflik)
| Topik | Keputusan |
|---|---|
| Navigasi halaman | **Semua `<section>` dimuat sekali, pindah halaman = tampil/sembunyi lewat `navigateTo()` (0 ms)**. Jangan memanggil server hanya untuk pindah halaman (aturan gas-instant-ux). Mengambil HTML halaman dari server (`getPageContent`) hanya untuk halaman berat/terbatas peran, dan yang dikirim sebaiknya **data**, bukan HTML. |
| Aturan iframe | `doGet()` tanpa `e.parameter.page`/token di URL; `setXFrameOptionsMode(ALLOWALL)`; dilarang `window.location`, `window.open`, `google.script.host.close()`; link = `javascript:void(0)` + `onclick`; URL tidak boleh berubah. |
| Login | **Jangan menyimpan password di Sheet** (versi lama gas-spa-iframe memakai username+password teks biasa: tidak aman). Untuk login Google di monolit, lihat catatan di bawah dan `08-google-login.md`. |
| Setup | `setupAppEnvironment()` **idempoten** (aman diulang): cek dulu sebelum membuat folder/sheet. |
| Keamanan teks | Semua data pengguna yang dimasukkan ke `innerHTML` wajib di-*escape* (lihat `UI.esc` di starter). |
| Penulisan sheet | Selalu `getValues()/setValues()` massal, tidak ada `getValue()/setValue()` di dalam loop. |

> **Batasan penting login Google di monolit**: halaman yang disajikan HtmlService berjalan di domain
> `googleusercontent.com`, sehingga tombol Google Sign-In (butuh *Authorized JavaScript origins* yang cocok)
> tidak praktis. Jika aplikasi butuh login Gmail, **naikkan ke Level 3** (frontend terpisah + GAS REST) — itulah
> alasan utama jalur tangga di SKILL.md. Untuk aplikasi internal satu organisasi Google Workspace, alternatifnya
> deploy dengan "Execute as: User accessing the web app" dan baca `Session.getActiveUser().getEmail()`
> (pengguna harus login Google; tidak berlaku untuk akses "Anyone" anonim).

## 4 Prinsip UX instan (wajib)
1. **SPA sisi klien** — navigasi tanpa panggilan server.
2. **Optimistic UI + localStorage** — UI diperbarui seketika, simpan ke localStorage, sinkron ke server di latar belakang
   (keranjang, favorit, draf form autosave). Jika server gagal, beri tahu dan pulihkan.
   *Catatan artefak/iframe tertentu memblokir localStorage: bungkus dengan try/catch.*
3. **Cache server** — `CacheService` untuk data master (TTL: katalog 3600 s, menu 1800 s, preferensi 300 s,
   transaksi tidak di-cache); **invalidate setiap tulis**.
4. **Batch** — 1 panggilan server untuk banyak operasi (simpan transaksi + kurangi stok + log + email), `LockService`
   untuk penulisan bersamaan.
Tambahan: *debounce* 300 ms untuk pencarian dan filter di data lokal (`window.appState`), jangan tanya server per ketikan.

## Fitur wajib (centang saat menghasilkan kode)
Auto-Setup · navigasi SPA (sidebar desktop / bottom-nav mobile) · mode gelap (CSS variables, tersimpan) · mobile-first
(Bootstrap 5 via CDN) · dashboard (kartu KPI + grafik Chart.js + panel insight teks otomatis) · CRUD master data ·
Pengaturan (identitas aplikasi, peran) · indikator loading/skeleton · `try-catch` di semua fungsi backend yang
mengembalikan `{success, data, message}` · validasi klien **dan** server · pratinjau file dalam modal (bukan tab baru)
· panduan instalasi.

## Alur 5 tahap (bila pengguna langsung mulai di Level 2)
Ide → PRD (`01`) → diskusi/persetujuan → referensi visual (`02`) → eksekusi kode 4 file sekaligus + panduan instalasi.

## Panduan instalasi (sertakan di akhir setiap penyerahan kode)
```
📋 PANDUAN INSTALASI & DEPLOY
1. Buka https://script.google.com → Proyek baru.
2. Ganti isi Code.gs dengan kode "Kode.gs", ubah nama file menjadi "Kode".
3. File → Baru → HTML: buat "Index", "Stylesheet", "JavaScript" (tanpa .html), tempel kodenya.
4. Pilih fungsi setupAppEnvironment → ▶ Jalankan → izinkan akses → cek Log eksekusi (URL Sheet & Folder).
5. Deploy → Deployment baru → Aplikasi web → Jalankan sebagai: Saya; Siapa yang punya akses: Siapa saja → Deploy → salin URL /exec.
6. Buka URL tersebut di browser.
⚠️ Setiap mengubah kode: Deploy → Kelola deployment → Edit (versi baru) agar URL /exec tetap sama.
```
> Catatan: skill sumber menulis "buat New Deployment baru" tiap perubahan, yang menghasilkan URL baru. Lebih baik
> **edit deployment yang ada → versi baru** supaya URL tidak berubah (penting setelah URL ditanam di Blogger/GitHub).

## Saran naik level (sampaikan di akhir Level 2)
Jika aplikasi dipakai orang banyak, perlu SEO, tampil di domain sendiri, atau butuh login Gmail → tawarkan Level 3.
