# Pusat Pemecahan Masalah (semua level)

Cara kerja: baca pesan/screenshot **dengan teliti**, cari baris galat terakhir, lanjutkan dari titik itu. Jangan
minta pengguna mengulang dari nol. Bedakan "tampak aneh tapi normal" (mis. password tak terlihat saat diketik) dari galat nyata.

## GAS (backend)
| Gejala | Penyebab | Solusi |
|---|---|---|
| Halaman putih / diminta login Google di iframe | Akses deployment bukan "Siapa saja" | Kelola deployment → Siapa saja |
| Perubahan kode tidak berlaku | Deployment lama | Kelola deployment → Edit → Versi baru (URL tetap) |
| `Script Properties` kosong / "Sheet ... tidak ada" | `setupAppEnvironment()` belum jalan/gagal di tengah | Jalankan lagi (idempoten), cek Log eksekusi |
| `Exception: Authorization required` | Izin belum diberikan | Jalankan fungsi dari editor → Tinjau izin → Izinkan |
| Lambat | Loop `getValue/setValue`, tanpa cache | Batch + CacheService (`03`) |
| `Service invoked too many times` / kuota | Terlalu banyak panggilan | Cache, batch, kurangi polling; periksa kuota resmi |
| Data lama tampil setelah simpan | Cache tidak di-invalidate | `cache.remove(...)` setelah setiap tulis |

## Frontend ↔ GAS
| Gejala | Penyebab | Solusi |
|---|---|---|
| Galat CORS di Console | POST pakai `application/json`, atau URL `/dev` | Pakai `text/plain;charset=utf-8` dan URL `/exec` |
| `Unexpected token <` saat `res.json()` | Backend mengembalikan HTML (halaman izin/galat) | Cek deployment "Siapa saja" & `ContentService` |
| Data kosong padahal ada | `GAS_URL` salah / belum diisi di `js/config.js` | Perbaiki lalu `git add . && git commit && git push` |
| Form me-reload halaman | Lupa `e.preventDefault()` | Tambahkan |

## GitHub / Pages / Vercel
Lihat tabel lengkap di `06-github-pages.md` (404, CSS/JS 404, `Password authentication is not supported`,
`src refspec main`, `remote origin already exists`, `--force` aman/tidaknya). Tambahan:
| Gejala | Solusi |
|---|---|
| Vercel build gagal pada situs statis | Framework Preset "Other", kosongkan Build Command |
| Domain sendiri belum aktif | Tunggu propagasi DNS; cocokkan catatan A/CNAME persis seperti yang ditampilkan |
| Situs terblokir/berhenti di Vercel Hobby | Kuota habis atau penggunaan komersial → lihat `07` |
| Tampilan lama setelah push | Ctrl+Shift+R atau jendela Incognito |

## Login Google
Lihat tabel di `08-google-login.md`.

## Blogger
Lihat bagian "Masalah umum" di `04-blogger-embed.md`.
