# Level 3a — Frontend terpisah + GAS sebagai REST API (inti gas-pro-api, diperkuat)

Frontend statis (HTML/CSS/JS murni) di Blogger/GitHub Pages/Netlify/Vercel; GAS hanya mengembalikan **JSON**.
Tanpa `google.script.run`, tanpa iframe, tanpa `HtmlService`.

**Starter siap pakai**: `assets/starter/backend/Kode.gs` (REST + login Google + peran + cache + lock; sudah diuji
dengan simulasi) dan `assets/starter/frontend/` (index.html, css/, js/). Salin lalu sesuaikan dengan PRD
(nama sheet/kolom, `IZIN`, halaman).

## Keuntungan vs monolit
SEO baik · muat instan (tanpa 2× loading) · UI responsif asli tanpa scrollbar ganda · domain bebas · bisa login
Google · bisa dipindah ke hosting lain tanpa ubah backend.

## Aturan emas (jangan dilanggar)
| Aturan | Alasan |
|---|---|
| POST memakai `Content-Type: text/plain;charset=utf-8` dan isi JSON | JSON murni memicu CORS preflight (OPTIONS) yang tidak didukung GAS |
| **Token/ID selalu di body POST, bukan URL/header** | GAS tak bisa membaca header custom; URL tercatat di log & riwayat |
| `doGet` hanya data publik | GET tidak boleh membawa kredensial |
| `doGet/doPost` mengembalikan `ContentService` JSON | bukan `HtmlService` |
| Semua fungsi publik `try-catch`, pesan error umum ke klien, detail ke `Logger` | jangan bocorkan stack/ID internal |
| ID di Script Properties, bukan hardcode | aman dan mudah dipindah |
| Cache baca, invalidate saat tulis | kecepatan & kuota |
| `setupAppEnvironment()` idempoten | pemula sering menjalankan dua kali |
| Escape semua teks dari server sebelum `innerHTML` | cegah XSS |
| Deploy: Execute as **Me**, akses **Anyone** — otorisasi dilakukan **di kode** (sesi + peran) | "Anyone" bukan berarti data terbuka |

## Struktur frontend (WAJIB — sesuai kontrak GitHub Pages di `06`)
```
nama-aplikasi/          ← folder ini = root repository (git init di sini)
├── index.html          ← harus di root
├── README.md
├── PANDUAN-INSTALASI.md
├── css/style.css
└── js/ config.js  api.js  auth.js  app.js
```
Isi `js/config.js` (GAS_URL, GOOGLE_CLIENT_ID) SEBELUM push pertama. File `.gs` **tidak** masuk ZIP/repo.

## Alur kerja 5 tahap (jika memulai langsung di Level 3)
Ide → PRD (`01`, tandai "Data dibaca vs ditulis" dan peran) → persetujuan ("✅ PRD FINAL DISETUJUI") →
visual (`02`) → kode: **5A backend `Kode.gs`**, **5B frontend** + panduan instalasi.

## Penyerahan berkas (kontrak `06-github-pages.md`)
- `Kode.gs` (& `appsscript.json`): **berkas terpisah satu per satu** (`present_files`), bukan ZIP.
- Frontend: **satu ZIP** dengan `index.html` di root ZIP (tanpa folder pembungkus `frontend/`).
- Panduan: `.md`/`.pdf` disajikan terpisah **dan** satu salinan di dalam ZIP.
- Sebutkan eksplisit folder mana yang di-`git init`.

## Daftar cek sebelum menyerahkan
Backend: JSON bukan HTML · `postData.contents` di-parse · CONFIG dari Properties · setup diuji · AppConfig terisi ·
cache + invalidate · try-catch · izin per aksi · deploy Me/Anyone.
Frontend: GAS_URL benar `/exec` · POST `text/plain` · `preventDefault` di form · loading & error ramah ·
responsif · tidak ada `google.script.run`.

## Panduan uji
Buka situs → data tampil → login Google → simpan form → cek Google Sheets → DevTools (F12) → Network: tidak ada error CORS.
