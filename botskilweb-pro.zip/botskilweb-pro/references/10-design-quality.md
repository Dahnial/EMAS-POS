# Kualitas Desain UI/UX (gabungan ui-ux-pro-max + design-system + ui-styling)

Dipakai di SETIAP level saat menulis atau meninjau tampilan. Basis data pencarian `ui-ux-pro-max` (`scripts/search.py`)
**tidak ikut terbawa** di berkas skill yang diunggah — jika skill aslinya terpasang, boleh dipakai
(`--design-system`, `--domain`, `--stack html-tailwind`); jika tidak, pakai tabel di bawah dan katakan terus terang
bahwa rekomendasi berasal dari aturan bawaan.

## 1. Prioritas aturan (kerjakan dari atas)
| # | Kategori | Wajib | Hindari |
|---|---|---|---|
| 1 | Aksesibilitas (KRITIS) | Kontras teks 4,5:1, alt gambar, navigasi keyboard, aria-label | Menghapus focus ring, tombol ikon tanpa label |
| 2 | Sentuhan & interaksi (KRITIS) | Target ≥ 44×44 px, jarak ≥ 8 px, umpan balik loading | Hanya mengandalkan hover, perubahan keadaan instan tanpa transisi |
| 3 | Kinerja | WebP/AVIF, lazy-load, sisihkan ruang (CLS < 0,1) | Layout bergeser, gambar raksasa |
| 4 | Pemilihan gaya | Sesuai jenis produk, konsisten, ikon SVG | Emoji sebagai ikon UI, campur gaya acak |
| 5 | Tata letak responsif | Mobile-first, meta viewport, tanpa scroll horizontal | Lebar piksel tetap, menonaktifkan zoom |
| 6 | Tipografi & warna | Dasar 16 px, line-height 1,5, token warna semantik | Teks < 12 px, abu di atas abu, HEX mentah di komponen |
| 7 | Animasi | 150–300 ms, bermakna, hormati `prefers-reduced-motion` | Animasi dekoratif, menganimasikan width/height |
| 8 | Form & umpan balik | Label terlihat, galat di dekat kolom, teks bantu | Placeholder sebagai label, galat hanya di atas |
| 9 | Navigasi | Tombol kembali jelas, bottom-nav ≤ 5, tautan dalam | Menu menumpuk, back rusak |
| 10 | Grafik & data | Legenda, tooltip, warna aksesibel | Makna hanya lewat warna |

## 2. Token desain 3 lapis (design-system)
`primitif (nilai mentah) → semantik (makna) → komponen`. Komponen tidak boleh memakai HEX mentah.
```css
--c-navy-700:#1E3A5F;           /* primitif */
--primary: var(--c-navy-700);   /* semantik */
--btn-bg: var(--primary);       /* komponen */
```
Mode gelap = menimpa lapis **semantik** di `[data-theme="dark"]` (contoh nyata: `assets/starter/frontend/css/style.css`).
Skala jarak 4/8 px; radius kartu 12, tombol/input 8; bayangan halus; ukuran teks H1/H2/body/caption terdefinisi.
Presentasi/deck merek: impor token CSS yang sama, grafik pakai Chart.js, navigasi keyboard.

## 3. Memilih tumpukan teknologi UI
| Level | Tumpukan | Alasan |
|---|---|---|
| 2 (GAS monolit) | Bootstrap 5 via CDN + CSS variables | Tanpa build, jalan di HtmlService |
| 3–4 (statis) | HTML/CSS/JS murni + token CSS (starter) | Ringan, mudah dipahami pemula |
| 5 | Next.js + Tailwind + shadcn/ui (Radix, aksesibel) | Komponen dialog/form/tabel berstandar tinggi, tema lewat variabel CSS |

## 4. Daftar cek sebelum menyerahkan tampilan (web)
- [ ] Kontras teks ≥ 4,5:1 di mode terang **dan** gelap; status tidak hanya dibedakan lewat warna
- [ ] Semua kontrol bisa dipakai keyboard, fokus terlihat; target sentuh ≥ 44 px
- [ ] Responsif 360 px – 1440 px, tanpa scroll horizontal (tabel lebar di dalam pembungkus `overflow-x:auto`)
- [ ] Ada keadaan: loading (skeleton/spinner), kosong (pesan ramah + tombol aksi), galat (jelas + cara memperbaiki), sukses (toast)
- [ ] Form: label terlihat, validasi inline, tombol dinonaktifkan saat mengirim
- [ ] Ikon SVG/ikon font konsisten (bukan emoji sebagai ikon fungsi)
- [ ] Animasi ≤ 300 ms dan mati bila `prefers-reduced-motion`
- [ ] Token warna dipakai; tidak ada HEX mentah di komponen
- [ ] Judul `<title>`, `meta description`, favicon, bahasa `lang="id"`
- [ ] Teks dari server di-escape sebelum `innerHTML`
Laporkan hasil daftar cek ke pengguna dalam 2–3 kalimat, jangan tempel seluruh daftar.

## 5. Dial gaya (bila ingin menyetel)
Variasi (minimal ↔ berani), gerak (halus ↔ koreografi), kepadatan (lega 24–96 px ↔ padat dashboard 8–32 px).
Dashboard = padat; landing = lega.
