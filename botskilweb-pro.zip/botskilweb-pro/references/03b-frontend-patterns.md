# Frontend Patterns — Index.html, Stylesheet.html, JavaScript.html

Patterns for the three HTML files that make up the GAS web app's frontend. Together with Kode.gs
they form the complete SPA.

---

## Index.html — The Shell

This is the only file served by `doGet()`. It includes the other two files and contains the
structural HTML.

```html
<!DOCTYPE html>
<html lang="id" data-theme="light">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Nama Aplikasi</title>

  <!-- Bootstrap 5 CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet">
  <!-- Bootstrap Icons -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css"
        rel="stylesheet">
  <!-- Google Fonts (sesuaikan dengan referensi visual) -->
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap"
        rel="stylesheet">

  <?!= include('Stylesheet') ?>
</head>
<body>

  <!-- Loading Overlay (tampil saat halaman pertama kali dimuat) -->
  <div id="loadingOverlay" class="loading-overlay">
    <div class="spinner-border text-primary" role="status">
      <span class="visually-hidden">Memuat...</span>
    </div>
    <p class="mt-3">Memuat aplikasi...</p>
  </div>

  <!-- Sidebar Navigation (untuk Desktop) -->
  <nav id="sidebar" class="sidebar">
    <div class="sidebar-header">
      <img id="appLogo" src="" alt="Logo" class="app-logo">
      <h5 id="appTitle">Nama Aplikasi</h5>
    </div>
    <ul class="sidebar-nav">
      <li><a href="#" onclick="navigateTo('dashboard')" class="nav-link active"
             data-section="dashboard">
        <i class="bi bi-speedometer2"></i> <span>Dashboard</span>
      </a></li>
      <li><a href="#" onclick="navigateTo('dataUtama')" class="nav-link"
             data-section="dataUtama">
        <i class="bi bi-database"></i> <span>Data Utama</span>
      </a></li>
      <li><a href="#" onclick="navigateTo('masterData')" class="nav-link"
             data-section="masterData">
        <i class="bi bi-collection"></i> <span>Master Data</span>
      </a></li>
      <li><a href="#" onclick="navigateTo('pengaturan')" class="nav-link"
             data-section="pengaturan">
        <i class="bi bi-gear"></i> <span>Pengaturan</span>
      </a></li>
    </ul>

    <!-- Dark Mode Toggle -->
    <div class="sidebar-footer">
      <div class="form-check form-switch">
        <input class="form-check-input" type="checkbox" id="darkModeToggle"
               onchange="toggleDarkMode()">
        <label class="form-check-label" for="darkModeToggle">
          <i class="bi bi-moon-stars"></i> Mode Gelap
        </label>
      </div>
    </div>
  </nav>

  <!-- Main Content Area -->
  <main id="mainContent" class="main-content">

    <!-- Top Bar (Mobile) -->
    <div class="topbar d-md-none">
      <button class="btn btn-link" onclick="toggleSidebar()">
        <i class="bi bi-list fs-4"></i>
      </button>
      <h6 id="pageTitle" class="mb-0">Dashboard</h6>
      <button class="btn btn-link" onclick="toggleDarkMode()">
        <i class="bi bi-moon-stars"></i>
      </button>
    </div>

    <!-- Section: Dashboard -->
    <section id="section-dashboard" class="content-section active">
      <!-- KPI Cards, Charts, AI Insights go here -->
    </section>

    <!-- Section: Data Utama -->
    <section id="section-dataUtama" class="content-section">
      <!-- Data table, Add/Edit forms -->
    </section>

    <!-- Section: Master Data -->
    <section id="section-masterData" class="content-section">
      <!-- CRUD for reference data -->
    </section>

    <!-- Section: Pengaturan -->
    <section id="section-pengaturan" class="content-section">
      <!-- Settings forms -->
    </section>

  </main>

  <!-- Modal: Konfirmasi Hapus -->
  <div class="modal fade" id="deleteModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Konfirmasi Hapus</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <p>Apakah Anda yakin ingin menghapus data ini?</p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
          <button type="button" class="btn btn-danger" id="confirmDeleteBtn">Hapus</button>
        </div>
      </div>
    </div>
  </div>

  <!-- Modal: Preview Dokumen -->
  <div class="modal fade" id="previewModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Pratinjau Dokumen</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body text-center">
          <div id="previewContent"></div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
            <i class="bi bi-x-lg"></i> Tutup
          </button>
          <a id="downloadBtn" href="#" class="btn btn-primary" target="_blank">
            <i class="bi bi-download"></i> Unduh
          </a>
        </div>
      </div>
    </div>
  </div>

  <!-- Toast Notification -->
  <div class="toast-container position-fixed bottom-0 end-0 p-3">
    <div id="appToast" class="toast" role="alert">
      <div class="toast-header">
        <strong class="me-auto" id="toastTitle">Notifikasi</strong>
        <button type="button" class="btn-close" data-bs-dismiss="toast"></button>
      </div>
      <div class="toast-body" id="toastBody"></div>
    </div>
  </div>

  <!-- Bootstrap JS Bundle -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js">
  </script>
  <!-- Chart.js (or ApexCharts — pick one per project) -->
  <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.4/dist/chart.umd.min.js"></script>

  <?!= include('JavaScript') ?>
</body>
</html>
```

### Important Index.html notes
- `data-theme="light"` on `<html>` controls the active theme.
- Every content section has `id="section-{name}"` and class `content-section`.
- Only one section has the `active` class at a time.
- Modals use Bootstrap's standard pattern with `data-bs-dismiss`.
- Toast for non-blocking notifications.

---

## Stylesheet.html — Theming & Responsive Layout

Wrap all CSS in a `<style>` tag. Use CSS custom properties extensively for the dual-theme system.

```html
<style>
/* ── CSS Custom Properties: Light Theme (Default) ── */
:root, [data-theme="light"] {
  --bg-primary: #f8f9fa;
  --bg-secondary: #ffffff;
  --bg-card: #ffffff;
  --text-primary: #212529;
  --text-secondary: #6c757d;
  --border-color: #dee2e6;
  --accent: #4361ee;
  --accent-hover: #3a56d4;
  --accent-light: rgba(67, 97, 238, 0.1);
  --sidebar-bg: #1a1a2e;
  --sidebar-text: #a8a8b8;
  --sidebar-active: #ffffff;
  --shadow: 0 2px 8px rgba(0,0,0,0.08);
  --card-radius: 12px;
}

/* ── Dark Theme ── */
[data-theme="dark"] {
  --bg-primary: #0f0f23;
  --bg-secondary: #1a1a2e;
  --bg-card: #16213e;
  --text-primary: #e4e4e7;
  --text-secondary: #9ca3af;
  --border-color: #2d2d44;
  --accent: #6366f1;
  --accent-hover: #818cf8;
  --accent-light: rgba(99, 102, 241, 0.15);
  --sidebar-bg: #0a0a1a;
  --sidebar-text: #6b7280;
  --sidebar-active: #e4e4e7;
  --shadow: 0 2px 8px rgba(0,0,0,0.3);
}

/* ── Transition untuk Dark Mode yang mulus ── */
*, *::before, *::after {
  transition: background-color 0.3s ease, color 0.3s ease, border-color 0.3s ease;
}

/* ── Body ── */
body {
  font-family: 'Inter', sans-serif;
  background-color: var(--bg-primary);
  color: var(--text-primary);
  margin: 0;
  padding: 0;
}

/* ── Loading Overlay ── */
.loading-overlay {
  position: fixed;
  top: 0; left: 0;
  width: 100%; height: 100%;
  background: var(--bg-primary);
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  z-index: 9999;
}

/* ── Sidebar ── */
.sidebar {
  position: fixed;
  top: 0; left: 0;
  width: 260px;
  height: 100vh;
  background: var(--sidebar-bg);
  color: var(--sidebar-text);
  display: flex;
  flex-direction: column;
  z-index: 1000;
  overflow-y: auto;
}
.sidebar-header {
  padding: 1.5rem;
  text-align: center;
  border-bottom: 1px solid rgba(255,255,255,0.1);
}
.app-logo { width: 48px; height: 48px; border-radius: 10px; margin-bottom: 0.5rem; }
.sidebar-header h5 { color: #fff; font-size: 1rem; margin: 0; }
.sidebar-nav {
  list-style: none; padding: 0.5rem 0; margin: 0; flex: 1;
}
.sidebar-nav .nav-link {
  display: flex; align-items: center; gap: 0.75rem;
  padding: 0.75rem 1.5rem;
  color: var(--sidebar-text);
  text-decoration: none;
  border-radius: 0;
  font-size: 0.9rem;
}
.sidebar-nav .nav-link:hover,
.sidebar-nav .nav-link.active {
  color: var(--sidebar-active);
  background: rgba(255,255,255,0.08);
}
.sidebar-footer {
  padding: 1rem 1.5rem;
  border-top: 1px solid rgba(255,255,255,0.1);
}
.sidebar-footer .form-check-label { color: var(--sidebar-text); font-size: 0.85rem; }

/* ── Main Content ── */
.main-content {
  margin-left: 260px;
  padding: 1.5rem;
  min-height: 100vh;
}

/* ── Top Bar (Mobile Only) ── */
.topbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0.75rem 0;
  margin-bottom: 1rem;
  border-bottom: 1px solid var(--border-color);
}

/* ── Content Sections ── */
.content-section { display: none; }
.content-section.active { display: block; }

/* ── Cards ── */
.card, .stat-card {
  background: var(--bg-card);
  border: 1px solid var(--border-color);
  border-radius: var(--card-radius);
  box-shadow: var(--shadow);
}
.stat-card {
  padding: 1.25rem;
  text-align: center;
}
.stat-card .stat-value {
  font-size: 1.75rem; font-weight: 700; color: var(--accent);
}
.stat-card .stat-label {
  font-size: 0.8rem; color: var(--text-secondary); margin-top: 0.25rem;
}

/* ── Tabel Responsif ── */
.table-responsive { border-radius: var(--card-radius); overflow: hidden; }
.table {
  color: var(--text-primary);
  margin-bottom: 0;
}
.table thead th {
  background: var(--accent);
  color: #fff;
  font-weight: 600;
  font-size: 0.85rem;
  white-space: nowrap;
  border: none;
}
.table tbody td {
  vertical-align: middle;
  font-size: 0.875rem;
  border-color: var(--border-color);
}
.table tbody tr:hover { background: var(--accent-light); }

/* ── Insight Card (AI Panel) ── */
.insight-card {
  background: linear-gradient(135deg, var(--accent), var(--accent-hover));
  color: #fff;
  border-radius: var(--card-radius);
  padding: 1.5rem;
}
.insight-card h6 { font-weight: 600; margin-bottom: 1rem; }
.insight-card ul { padding-left: 1.25rem; margin: 0; }
.insight-card li { margin-bottom: 0.5rem; font-size: 0.9rem; }

/* ── Buttons ── */
.btn-accent {
  background: var(--accent);
  color: #fff;
  border: none;
  border-radius: 8px;
}
.btn-accent:hover { background: var(--accent-hover); color: #fff; }

/* ── Forms ── */
.form-control, .form-select {
  background: var(--bg-secondary);
  color: var(--text-primary);
  border-color: var(--border-color);
}
.form-control:focus, .form-select:focus {
  border-color: var(--accent);
  box-shadow: 0 0 0 0.2rem var(--accent-light);
  background: var(--bg-secondary);
  color: var(--text-primary);
}

/* ── Inline Loading Spinner ── */
.spinner-inline {
  display: inline-block;
  width: 1rem; height: 1rem;
  border: 2px solid var(--accent-light);
  border-top-color: var(--accent);
  border-radius: 50%;
  animation: spin 0.6s linear infinite;
}
@keyframes spin { to { transform: rotate(360deg); } }

/* ── Responsive: Mobile ── */
@media (max-width: 767.98px) {
  .sidebar {
    transform: translateX(-100%);
    transition: transform 0.3s ease;
  }
  .sidebar.show { transform: translateX(0); }
  .main-content { margin-left: 0; padding: 1rem; }
  .sidebar-overlay {
    display: none; position: fixed;
    top: 0; left: 0; width: 100%; height: 100%;
    background: rgba(0,0,0,0.5); z-index: 999;
  }
  .sidebar-overlay.show { display: block; }
}

/* ── Responsive: Tablet ── */
@media (min-width: 768px) and (max-width: 991.98px) {
  .sidebar { width: 220px; }
  .main-content { margin-left: 220px; }
}
</style>
```

### Theming guidelines
- Derive ALL colors from CSS custom properties — no hardcoded colors in component styles.
- The accent color should come from the reference image analysis; the examples above are defaults.
- Adapt sidebar colors, card radius, shadow depth to match the uploaded visual reference.
- The transition on `*` ensures the dark/light switch feels smooth, not jarring.

---

## JavaScript.html — SPA Logic, API Calls, Charts

Wrap all JavaScript in a `<script>` tag. Organize into logical sections with comment headers.

```html
<script>
/**
 * ============================================================
 * [NAMA APLIKASI] — Frontend JavaScript
 * ============================================================
 */

// ════════════════════════════════════════════════════════
// BAGIAN 1: INISIALISASI & NAVIGASI SPA
// ════════════════════════════════════════════════════════

/** Inisialisasi saat halaman selesai dimuat */
document.addEventListener('DOMContentLoaded', () => {
  initApp();
});

function initApp() {
  // Muat konfigurasi dan data awal
  google.script.run
    .withSuccessHandler(config => {
      if (config.success) {
        applyConfig(config.data);
      }
      loadDashboard();
      hideLoadingOverlay();
    })
    .withFailureHandler(err => {
      showToast('Error', 'Gagal memuat konfigurasi: ' + err.message, 'danger');
      hideLoadingOverlay();
    })
    .getAllConfig();

  // Terapkan tema tersimpan
  const savedTheme = localStorage.getItem('theme') || 'light';
  document.documentElement.setAttribute('data-theme', savedTheme);
  document.getElementById('darkModeToggle').checked = savedTheme === 'dark';
}

/** Navigasi SPA — sembunyikan semua section, tampilkan yang dipilih */
function navigateTo(sectionId) {
  // Sembunyikan semua section
  document.querySelectorAll('.content-section').forEach(s => s.classList.remove('active'));
  // Tampilkan section target
  const target = document.getElementById('section-' + sectionId);
  if (target) target.classList.add('active');

  // Update nav aktif
  document.querySelectorAll('.sidebar-nav .nav-link').forEach(link => {
    link.classList.toggle('active', link.dataset.section === sectionId);
  });

  // Update judul halaman (mobile)
  const titles = {
    dashboard: 'Dashboard',
    dataUtama: 'Data Utama',
    masterData: 'Master Data',
    pengaturan: 'Pengaturan'
  };
  document.getElementById('pageTitle').textContent = titles[sectionId] || 'Halaman';

  // Tutup sidebar di mobile
  closeSidebar();

  // Muat data section jika perlu
  if (sectionId === 'dashboard') loadDashboard();
  if (sectionId === 'dataUtama') loadDataUtama();
  if (sectionId === 'masterData') loadMasterData();
  if (sectionId === 'pengaturan') loadSettings();
}

// ════════════════════════════════════════════════════════
// BAGIAN 2: DARK MODE
// ════════════════════════════════════════════════════════

function toggleDarkMode() {
  const html = document.documentElement;
  const current = html.getAttribute('data-theme');
  const next = current === 'dark' ? 'light' : 'dark';
  html.setAttribute('data-theme', next);
  localStorage.setItem('theme', next);
  document.getElementById('darkModeToggle').checked = next === 'dark';

  // Perbarui chart jika ada (warna grid/label menyesuaikan tema)
  updateChartsTheme(next);
}

// ════════════════════════════════════════════════════════
// BAGIAN 3: SIDEBAR MOBILE
// ════════════════════════════════════════════════════════

function toggleSidebar() {
  document.getElementById('sidebar').classList.toggle('show');
  // Overlay di belakang sidebar
  let overlay = document.querySelector('.sidebar-overlay');
  if (!overlay) {
    overlay = document.createElement('div');
    overlay.className = 'sidebar-overlay';
    overlay.onclick = closeSidebar;
    document.body.appendChild(overlay);
  }
  overlay.classList.toggle('show');
}

function closeSidebar() {
  document.getElementById('sidebar').classList.remove('show');
  const overlay = document.querySelector('.sidebar-overlay');
  if (overlay) overlay.classList.remove('show');
}

// ════════════════════════════════════════════════════════
// BAGIAN 4: UTILITAS UI
// ════════════════════════════════════════════════════════

/** Sembunyikan loading overlay awal */
function hideLoadingOverlay() {
  const overlay = document.getElementById('loadingOverlay');
  if (overlay) {
    overlay.style.opacity = '0';
    setTimeout(() => overlay.style.display = 'none', 300);
  }
}

/** Tampilkan toast notifikasi */
function showToast(title, message, type = 'info') {
  const toastEl = document.getElementById('appToast');
  document.getElementById('toastTitle').textContent = title;
  document.getElementById('toastBody').textContent = message;

  // Warna border sesuai tipe
  toastEl.className = 'toast';
  toastEl.style.borderLeft = `4px solid var(--${type === 'danger' ? 'bs-danger' : type === 'success' ? 'bs-success' : 'accent'})`;

  const toast = new bootstrap.Toast(toastEl, { delay: 4000 });
  toast.show();
}

/** Tampilkan/sembunyikan loading inline di sebuah container */
function showLoading(containerId) {
  const el = document.getElementById(containerId);
  if (el) el.innerHTML = `
    <div class="text-center py-4">
      <div class="spinner-border text-primary" role="status"></div>
      <p class="mt-2 text-muted">Memuat data...</p>
    </div>`;
}

/** Terapkan konfigurasi dari AppConfig */
function applyConfig(config) {
  if (config.appName) {
    document.getElementById('appTitle').textContent = config.appName;
    document.title = config.appName;
  }
  if (config.logoUrl) {
    document.getElementById('appLogo').src = config.logoUrl;
  }
}

// ════════════════════════════════════════════════════════
// BAGIAN 5: DASHBOARD & CHART
// ════════════════════════════════════════════════════════

let chartInstances = {};

function loadDashboard() {
  showLoading('section-dashboard');
  google.script.run
    .withSuccessHandler(renderDashboard)
    .withFailureHandler(err => showToast('Error', err.message, 'danger'))
    .getDashboardData();
}

function renderDashboard(response) {
  if (!response.success) {
    showToast('Error', response.message, 'danger');
    return;
  }
  const data = response.data;
  const container = document.getElementById('section-dashboard');

  // Bangun HTML dashboard
  container.innerHTML = `
    <!-- Baris KPI Cards -->
    <div class="row g-3 mb-4">
      <div class="col-6 col-md-3">
        <div class="stat-card">
          <div class="stat-value">${data.totalRecords}</div>
          <div class="stat-label">Total Data</div>
        </div>
      </div>
      ${Object.entries(data.statusCounts).map(([status, count]) => `
        <div class="col-6 col-md-3">
          <div class="stat-card">
            <div class="stat-value">${count}</div>
            <div class="stat-label">${status}</div>
          </div>
        </div>
      `).join('')}
    </div>

    <!-- Chart & Insight -->
    <div class="row g-3">
      <div class="col-md-8">
        <div class="card p-3">
          <h6 class="mb-3">Distribusi Kategori</h6>
          <canvas id="chartKategori" height="250"></canvas>
        </div>
      </div>
      <div class="col-md-4">
        <div class="insight-card">
          <h6><i class="bi bi-lightbulb"></i> Analisis AI</h6>
          <ul>
            ${data.insights.map(i => `<li>${i}</li>`).join('')}
          </ul>
        </div>
      </div>
    </div>
  `;

  // Render chart
  renderCategoryChart(data.categoryCounts);
}

function renderCategoryChart(categoryCounts) {
  const ctx = document.getElementById('chartKategori');
  if (!ctx) return;

  // Hancurkan chart lama jika ada
  if (chartInstances.kategori) chartInstances.kategori.destroy();

  const labels = Object.keys(categoryCounts);
  const values = Object.values(categoryCounts);
  const isDark = document.documentElement.getAttribute('data-theme') === 'dark';

  chartInstances.kategori = new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels,
      datasets: [{
        data: values,
        backgroundColor: ['#4361ee','#3a0ca3','#7209b7','#f72585','#4cc9f0','#4895ef'],
        borderWidth: 0
      }]
    },
    options: {
      responsive: true,
      plugins: {
        legend: {
          position: 'bottom',
          labels: { color: isDark ? '#e4e4e7' : '#212529', padding: 12 }
        }
      }
    }
  });
}

function updateChartsTheme(theme) {
  // Redraw charts with correct text color for the active theme
  Object.values(chartInstances).forEach(chart => {
    if (chart.options.plugins && chart.options.plugins.legend) {
      chart.options.plugins.legend.labels.color = theme === 'dark' ? '#e4e4e7' : '#212529';
    }
    chart.update();
  });
}

// ════════════════════════════════════════════════════════
// BAGIAN 6: CRUD DATA UTAMA (POLA UMUM)
// ════════════════════════════════════════════════════════

function loadDataUtama() {
  showLoading('tableContainerUtama');
  google.script.run
    .withSuccessHandler(renderDataTable)
    .withFailureHandler(err => showToast('Error', err.message, 'danger'))
    .getAllData('DataUtama');
}

function renderDataTable(response) {
  // Bangun tabel dari response.data (array of objects)
  // Gunakan pola yang sama untuk Master Data
}

function saveRecord(formId, sheetName) {
  const form = document.getElementById(formId);
  if (!form.checkValidity()) {
    form.reportValidity();
    return;
  }

  const formData = new FormData(form);
  const record = {};
  formData.forEach((v, k) => record[k] = v);

  // Tampilkan loading pada tombol
  const submitBtn = form.querySelector('[type="submit"], .btn-save');
  const originalText = submitBtn.innerHTML;
  submitBtn.innerHTML = '<span class="spinner-inline"></span> Menyimpan...';
  submitBtn.disabled = true;

  const action = record.ID ? 'updateRecord' : 'addRecord';
  google.script.run
    .withSuccessHandler(res => {
      submitBtn.innerHTML = originalText;
      submitBtn.disabled = false;
      if (res.success) {
        showToast('Berhasil', res.message, 'success');
        form.reset();
        navigateTo(sheetName === 'DataUtama' ? 'dataUtama' : 'masterData');
      } else {
        showToast('Gagal', res.message, 'danger');
      }
    })
    .withFailureHandler(err => {
      submitBtn.innerHTML = originalText;
      submitBtn.disabled = false;
      showToast('Error', err.message, 'danger');
    })
    [action](sheetName, record);
}

function confirmDelete(id, sheetName) {
  const modal = new bootstrap.Modal(document.getElementById('deleteModal'));
  document.getElementById('confirmDeleteBtn').onclick = () => {
    google.script.run
      .withSuccessHandler(res => {
        modal.hide();
        if (res.success) {
          showToast('Berhasil', res.message, 'success');
          navigateTo(sheetName === 'DataUtama' ? 'dataUtama' : 'masterData');
        } else {
          showToast('Gagal', res.message, 'danger');
        }
      })
      .withFailureHandler(err => {
        modal.hide();
        showToast('Error', err.message, 'danger');
      })
      .deleteRecord(sheetName, id);
  };
  modal.show();
}

// ════════════════════════════════════════════════════════
// BAGIAN 7: PREVIEW FILE (MODAL)
// ════════════════════════════════════════════════════════

function previewFile(fileUrl, fileName, mimeType) {
  const content = document.getElementById('previewContent');
  const downloadBtn = document.getElementById('downloadBtn');
  downloadBtn.href = fileUrl;

  if (mimeType && mimeType.startsWith('image/')) {
    content.innerHTML = `<img src="${fileUrl}" class="img-fluid rounded" alt="${fileName}">`;
  } else {
    // Gunakan Google Docs Viewer untuk PDF/dokumen lain
    content.innerHTML = `<iframe src="https://docs.google.com/gview?url=${encodeURIComponent(fileUrl)}&embedded=true"
      style="width:100%;height:70vh;border:none;"></iframe>`;
  }

  const modal = new bootstrap.Modal(document.getElementById('previewModal'));
  document.querySelector('#previewModal .modal-title').textContent = fileName;
  modal.show();
}

// ════════════════════════════════════════════════════════
// BAGIAN 8: FILE UPLOAD (POLA)
// ════════════════════════════════════════════════════════

function handleFileUpload(inputId, callback) {
  const input = document.getElementById(inputId);
  const file = input.files[0];
  if (!file) { showToast('Peringatan', 'Pilih file terlebih dahulu.', 'warning'); return; }

  // Batas ukuran (misal 10MB)
  if (file.size > 10 * 1024 * 1024) {
    showToast('Peringatan', 'Ukuran file maksimal 10MB.', 'warning');
    return;
  }

  const reader = new FileReader();
  reader.onload = () => {
    const base64 = reader.result.split(',')[1];
    google.script.run
      .withSuccessHandler(res => {
        if (res.success) {
          showToast('Berhasil', 'File berhasil diupload.', 'success');
          if (callback) callback(res.data);
        } else {
          showToast('Gagal', res.message, 'danger');
        }
      })
      .withFailureHandler(err => showToast('Error', err.message, 'danger'))
      .uploadFileToDrive(base64, file.name, file.type);
  };
  reader.readAsDataURL(file);
}
</script>
```

### Important JavaScript patterns

1. **Every `google.script.run` call** has both success and failure handlers.
2. **Loading state** is always shown before a call and cleared after.
3. **Chart instances** are tracked in an object and destroyed before re-creating to prevent
   memory leaks.
4. **Dark mode** is saved to `localStorage` and restored on init.
5. **File preview** uses a modal with embedded viewer, not `window.open()`.
6. **Form validation** uses HTML5 native validation first, then checks server-side.
7. **Delete confirmation** always goes through a modal dialog, never direct.

---

## CDN Libraries Reference

Approved CDNs (use jsDelivr for consistency):

| Library         | CDN URL                                                              |
|-----------------|----------------------------------------------------------------------|
| Bootstrap 5 CSS | `cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css`   |
| Bootstrap 5 JS  | `cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js` |
| Bootstrap Icons | `cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css` |
| Chart.js        | `cdn.jsdelivr.net/npm/chart.js@4.4.4/dist/chart.umd.min.js`        |
| ApexCharts      | `cdn.jsdelivr.net/npm/apexcharts@3.49.1/dist/apexcharts.min.js`    |
| SweetAlert2     | `cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.all.min.js`  |
| Google Fonts    | `fonts.googleapis.com/css2?family=...`                              |

Pick Chart.js or ApexCharts per project, not both. SweetAlert2 is optional — Bootstrap toasts
and modals usually suffice.

---

## Adapting to Visual Reference

When the user provides a reference image, adapt these defaults:

1. **Color palette**: Replace all hex values in the `:root` and `[data-theme="dark"]` blocks.
2. **Font family**: Swap the Google Font import and `font-family` declaration.
3. **Card radius**: Adjust `--card-radius` (sharp = `4px`, rounded = `16px`).
4. **Sidebar style**: Match width, background gradient/solid, icon style.
5. **Button style**: Match border-radius, padding, hover effect.
6. **Chart colors**: Update the `backgroundColor` array in chart configs.
7. **Layout pattern**: Switch between sidebar nav, top nav, or bottom nav based on the reference.
