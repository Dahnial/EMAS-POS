# Level 5 — Standar perusahaan besar: kapan dan bagaimana naik kelas

Jangan langsung ke sini. Level 5 dipakai bila **pemicu** terpenuhi; jelaskan trade-off dengan jujur (biaya, kerumitan).

## Pemicu naik dari GAS+Sheets
| Pemicu | Respons |
|---|---|
| Pengguna bersamaan ratusan+, data puluhan ribu baris, kueri relasional, laporan berat | Ganti Sheets dengan database sungguhan (mis. Postgres via Supabase, atau Firebase/Firestore, atau Cloud SQL) |
| Perlu verifikasi login berstandar produksi, peran halus, SSO perusahaan | Backend Node/Next.js + Auth.js atau penyedia identitas (Google/Workspace SSO) |
| Batas kuota/waktu eksekusi GAS terasa (cek dokumentasi kuota Apps Script terbaru) | Pindahkan logika berat ke server sungguhan / fungsi serverless |
| Tim developer, uji otomatis, lingkungan staging | Repo GitHub + CI + Vercel preview + cabang `main` terlindungi |
Jika tidak ada pemicu, **Level 3–4 sudah cukup profesional** — katakan itu terang-terangan.

## Daftar cek "sekelas perusahaan" (gunakan sebagai rapor)
- **Identitas & akses**: login Google, daftar putih, peran, log audit, sesi berbatas waktu
- **Keamanan**: HTTPS wajib, tanpa rahasia di repo, escape input/output, validasi server, header keamanan, backup data terjadwal
- **Keandalan**: lingkungan terpisah (dev/staging/prod), pemantauan error (mis. Sentry), halaman status/404/500 ramah
- **Kinerja**: Lighthouse ≥ 90 mobile, gambar WebP/AVIF + lazy-load, tidak ada layout shift, cache
- **Aksesibilitas**: WCAG AA (kontras 4.5:1, label, fokus, keyboard)
- **Legal**: Kebijakan Privasi & Syarat Layanan (juga syarat consent screen Google), kontak resmi
- **Merek**: domain sendiri, favicon, OG image, email domain, desain berbasis token (`10`)
- **Operasional**: README, panduan admin, cara backup/restore, siapa pemegang akun (jangan satu orang saja)

## Jalur teknis (urut, setiap tahap bisa berhenti)
**5a. Rapikan repo & alur kerja** — repo GitHub rapi, `.gitignore`, cabang `main` + cabang fitur, Vercel preview tiap PR.
**5b. Frontend modern** — Next.js + Tailwind + shadcn/ui; pindahkan token desain (`10`) ke tema Tailwind;
  komponen aksesibel (dialog, form, tabel).
```bash
npx create-next-app@latest nama-app
cd nama-app
npx shadcn@latest init
npx shadcn@latest add button card dialog form input table
```
**5c. Login produksi** — Auth.js dengan provider Google (variabel lingkungan `AUTH_GOOGLE_ID`, `AUTH_GOOGLE_SECRET`,
`AUTH_SECRET`; Redirect URI `https://DOMAIN/api/auth/callback/google` ditambahkan di Google Cloud). *Nama variabel
dan jalur bisa berubah antar versi — cocokkan dengan dokumentasi resmi authjs.dev sebelum menulis.* Untuk SPA + API
terpisah: verifikasi ID token di server dengan `OAuth2Client.verifyIdToken({ idToken, audience: CLIENT_ID })`.
**5d. Data** — ekspor Sheet ke CSV → impor ke database; backend GAS bisa dipertahankan sementara sebagai
"adapter" sehingga migrasi bertahap. Uji dengan data salinan, bukan data asli, sebelum cut-over.
**5e. Operasi** — pemantauan, backup, domain + email, dokumentasi, pelatihan admin.

## Cara memandu pemula di level ini
Claude menulis kode dan perintah; pengguna menjalankan satu langkah per giliran dan melapor lewat screenshot
(sama seperti `06`). Setiap tahap diakhiri: apa yang sekarang berjalan, apa risikonya, dan satu langkah berikutnya.
Perkirakan biaya bulanan (hosting berbayar, domain, database) dan minta persetujuan sebelum menyarankan layanan berbayar.
