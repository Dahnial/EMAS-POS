# Level 1 — Dari PRD ke Wireframe ke Desain UI/UX (gabungan prd-to-wireframe + wireframe-to-uiux)

Semua prompt untuk Google Stitch / Figma AI ditulis dalam **bahasa Inggris** (alat desain lebih akurat),
tetapi penjelasan ke pengguna tetap Bahasa Indonesia.

## A. Wireframe (struktur, tanpa warna)
1. **Ekstrak dari PRD**: nama & tujuan, peran, daftar halaman (publik + admin), fitur kunci per halaman, alur navigasi.
   Bila PRD belum ada → kembali ke `01-prd-interview.md`.
2. **Susun prompt** dengan struktur:
```
Create detailed wireframes for [APP]. Use grayscale wireframe style only — no colors, no images, just layout
structure, placeholder boxes, labels and navigation flow.
## Application Context
[2-3 sentences]. Has [N] main sections: [...]
## Wireframe Pages Required
--- PAGE W-01: [NAME] ---
Layout: [sidebar/navbar/columns]
- [Component]: [detail + labels]
...
## Wireframe Style Notes
- Grayscale only (#FFFFFF, #EEEEEE, #AAAAAA, #333333, #000000); real labels, not Lorem Ipsum
- Primary buttons filled dark, secondary outlined; images = box with X; charts = empty frame with axis labels
- Show a mobile frame for at least the HOME page; add flow arrows between key pages
```
3. **Urutan halaman**: publik → autentikasi (login Google) → pengguna → admin → pengaturan.
   Ideal 8–15 halaman per prompt; >15 dipecah (Publik+Auth / Admin).
4. **Pola halaman siap pakai**:
   - *Landing*: navbar | hero (H1, subjudul, CTA) | stats | grid fitur | footer
   - *Tabel admin*: sidebar + topbar; header [Judul][+ Tambah]; filter bar; tabel (checkbox, kolom, badge status, aksi); pagination
   - *Form*: [← Kembali][Judul]; seksi bertumpuk; bar aksi bawah (Batal / Simpan Draf / Kirim)
   - *Login*: kartu di tengah: logo, judul, **tombol "Masuk dengan Google"**, tautan bantuan
   - *Dashboard*: sidebar 220px; baris kartu KPI; grafik; tabel mini "terbaru"
   - *Review/Approval*: split 55/45 — pratinjau | metadata + Setujui/Tolak (modal catatan)
5. **Sajikan**: prompt dalam blok kode, tabel ringkasan halaman, tips pakai Stitch, lalu tawarkan lanjut ke UI/UX.

## B. Prompt UI/UX visual
1. **Kumpulkan**: gaya desain, warna merek (HEX), nama institusi/merek. Bila tak ada, pilih palet berikut sesuai konteks:

| Konteks | Primary | Surface | Accent | Teks |
|---|---|---|---|---|
| Akademik/Perpustakaan | Navy #1E3A5F | #F5F7FA | Amber #F5A623 | #1A1A2E |
| Bisnis/SaaS | Indigo #4F46E5 | #F8FAFC | Emerald #10B981 | #1E293B |
| Pemerintahan/Institusi | Hijau tua #1B4332 | #F9FAFB | Emas #D4A017 | #111827 |
| Toko/Perhiasan/Premium | Hitam-arang #1C1917 | #FAF7F2 | Emas #B8860B | #1C1917 |

2. **Struktur prompt**:
```
Design a complete UI/UX for [APP]. [2-3 sentences]
## Design Identity
- Style, Aesthetic (card-based, whitespace, shadows) | Palette (Primary/Background/Surface/Accent/Text/Border, all HEX + meaning)
- Typography (font + reason) | Icons (line, library) | Inspired by [2-3 real platforms: Linear, Stripe, Notion, Vercel…]
- Radius cards 12px / buttons 8px / inputs 8px | subtle shadows | 8px base grid
## Application Overview — [N] sections
### 1. [PAGE] — layout, then per component: color, size, state (hover/focus/disabled), empty state, skeleton loader
## Global Design Requirements
- Responsive (desktop primary, show tablet/mobile) | skeleton loading | toasts (green/red/blue/amber)
- Empty states with CTA | hover + visible focus ring | inline validation | dark mode variant
- Overall feel: [1-2 sentences]
```
3. **Wajib per halaman**: warna tombol (primary/secondary/danger), warna badge status, gaya kartu, empty/loading state,
   hierarki tipografi. Selalu HEX, bukan sekadar "biru".
4. **Badge status baku**: Aktif #DCFCE7/#166534 · Menunggu #FEF9C3/#854D0E · Ditolak #FEE2E2/#991B1B ·
   Draf #F1F5F9/#475569 · Info #DBEAFE/#1D4ED8.
5. **Setelah desain jadi**: minta pengguna mengunggah hasil Stitch → lakukan *analisis visual* (palet HEX, tipografi,
   pola layout, gaya komponen, mood) → konfirmasi → terapkan ke token CSS di starter (`css/style.css`).
6. **Iterasi**: bila belum cocok, perbaiki bagian yang spesifik saja, jangan tulis ulang seluruh prompt.

Kualitas akhir (aksesibilitas, kontras, sentuhan 44px, dll) dicek dengan `10-design-quality.md`.
