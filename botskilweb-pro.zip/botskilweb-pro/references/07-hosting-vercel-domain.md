# Level 4 — Hosting profesional: GitHub → Vercel/Netlify/Cloudflare + domain sendiri

Dimuat setelah frontend sudah jalan (Level 3). Fakta di bawah diperiksa pada Oktober 2026; **ketentuan layanan
berubah — periksa ulang halaman resmi sebelum pengguna membayar atau meluncurkan usaha**.

## 1. Batasan penggunaan komersial (JELASKAN SEBELUM memilih hosting)
Tanya dulu: *"Aplikasi ini dipakai untuk usaha / menghasilkan uang?"* (dari Sesi 4 PRD).

| Layanan | Ketentuan penting (diverifikasi) | Implikasi |
|---|---|---|
| **GitHub Pages** | Tidak boleh dipakai sebagai hosting gratis untuk menjalankan bisnis online, e-commerce, atau situs yang terutama untuk transaksi komersial/SaaS; jangan untuk transaksi sensitif (kirim password/kartu). Situs ≤1 GB, soft limit 100 GB/bulan, 10 build/jam. Repo publik untuk paket Free. | Cocok: portofolio, landing, katalog, edukasi, alat internal non-komersial, latihan. **Tidak cocok** untuk toko/kasir/SaaS berbayar. |
| **Vercel Hobby (gratis)** | Hanya untuk penggunaan **pribadi non-komersial** (termasuk meminta donasi dianggap komersial). Pro: $20/pengguna/bulan + pemakaian (harga per Sep 2026). Hobby berhenti saat kuota habis (tidak ditagih). | Untuk usaha → **Pro/Enterprise**. |
| **Netlify / Cloudflare Pages / lainnya** | *Belum diverifikasi di skill ini.* | Baca syarat resmi (halaman Pricing/Terms/Fair use) sebelum merekomendasikan untuk usaha. |

Pola jawaban yang jujur: sampaikan opsi gratis untuk belajar/non-komersial, dan opsi berbayar/bertanggung jawab
untuk usaha. Jangan menyarankan pelanggaran ketentuan agar "tetap gratis".

## 2. Kapan menyarankan pindah dari GAS-monolit/Blogger ke GitHub → Vercel
Tawarkan tangga ini **secara proaktif** saat salah satu pemicu muncul:
- Ingin login Gmail/Google, domain sendiri, SEO, atau tampilan setara perusahaan → Level 3 (GitHub) lalu Level 4.
- Tim/kolaborasi, riwayat perubahan, pratinjau tiap perubahan → GitHub + Vercel (preview deployments).
- Usaha berbayar → hosting yang mengizinkan komersial (lihat tabel).

## 3. Deploy ke Vercel dari GitHub (frontend statis hasil Level 3)
1. Pastikan repo sudah di GitHub dengan `index.html` di root (panduan `06`).
2. vercel.com → daftar dengan akun GitHub → **Add New → Project** → pilih repo → **Import**.
3. Framework Preset: **Other**; Build Command: kosong; Output Directory: kosong/`.`  → **Deploy**.
4. Hasil: `nama-proyek.vercel.app`. Setiap `git push` ke `main` otomatis deploy ulang; cabang lain → URL pratinjau.
5. **Wajib setelah URL baru**: tambahkan `https://nama-proyek.vercel.app` ke *Authorized JavaScript origins* di Google
   Cloud (`08`). Backend GAS tidak perlu diubah.
Netlify serupa: Add new site → Import from Git → tanpa build command, publish directory `.`.
Satu langkah per giliran, minta screenshot (aturan `06`).

## 4. Domain sendiri
1. Beli domain di registrar (mis. `.com`, `.id`, `.co.id` butuh syarat tambahan) — biaya tahunan.
2. Di Vercel/Netlify: Project → **Domains** → tambah domain; ikuti catatan DNS yang ditampilkan (A/CNAME) di panel registrar.
3. Tunggu propagasi (menit–jam); HTTPS (sertifikat) diterbitkan otomatis.
4. Perbarui *Authorized JavaScript origins* Google dengan `https://domain-anda.com` (dan `www` bila dipakai).
5. Opsional: email domain (Google Workspace) agar login & surat terlihat profesional.

## 5. Rahasia & konfigurasi
`GAS_URL` dan `GOOGLE_CLIENT_ID` **boleh publik** (memang terlihat di browser). Yang **tidak boleh** masuk repo:
client secret, API key bayar, token pribadi (`ghp_...`), isi `.env`. Tambahkan `.gitignore` berisi `.env*`.
Pada Level 5 simpan rahasia di *Environment Variables* Vercel, bukan di kode.

## 6. Laporan ke pengguna
Setelah live: berikan URL, ringkasan apa yang berjalan di mana (frontend = Vercel, backend = GAS, data = Sheets),
cara update (3 perintah git), dan **satu saran naik level berikutnya** (jangan menumpuk banyak saran).
